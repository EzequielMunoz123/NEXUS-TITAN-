package main

import "testing"

func TestStickerCommandAliases(t *testing.T) {
	for _, command := range []string{"!s", "!sticker", "!stikcer", "?sticker"} {
		if !isStickerCommand(command) {
			t.Errorf("se esperaba reconocer %q", command)
		}
	}
}
