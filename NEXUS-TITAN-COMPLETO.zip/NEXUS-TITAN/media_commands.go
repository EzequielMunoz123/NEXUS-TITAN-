package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"go.mau.fi/whatsmeow"
	waProto "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/types"
	"google.golang.org/protobuf/proto"
)

type PendingAudioForward struct {
	Data      []byte
	Mimetype  string
	PTT       bool
	CreatedAt time.Time
}

// quotedMessage recupera el mensaje citado por un comando de texto.
func quotedMessage(msg *waProto.Message) *waProto.Message {
	msg = unwrapIncomingMessage(msg)
	if msg == nil || msg.GetExtendedTextMessage() == nil || msg.GetExtendedTextMessage().GetContextInfo() == nil {
		return nil
	}
	return unwrapIncomingMessage(msg.GetExtendedTextMessage().GetContextInfo().GetQuotedMessage())
}

func isAudioForwardCommand(body string) bool {
	fields := strings.Fields(strings.ToLower(strings.TrimSpace(body)))
	if len(fields) == 0 {
		return false
	}
	switch strings.TrimRight(fields[0], ".,!¡¿;:") {
	case "!audio", "?audio", "!reenviaraudio", "!mandaraudio":
		return true
	default:
		return false
	}
}

// handleAudioForwardCommand descarga el audio citado y pide el número de destino.
func (b *Bot) handleAudioForwardCommand(chat types.JID, number string, message *waProto.Message, body string) bool {
	if !isAudioForwardCommand(body) {
		return false
	}
	if !isAdmin(number) {
		b.send(chat, "🔒 El comando !audio es exclusivo de administradores.")
		return true
	}
	fields := strings.Fields(strings.TrimSpace(body))
	mode := ""
	if len(fields) > 1 {
		mode = strings.ToLower(strings.TrimSpace(fields[1]))
	}
	quoted := quotedMessage(message)
	if quoted == nil {
		b.send(chat, "🎧 Respondé al audio con !audio todos, !audio pendientes o !audio NUMERO.")
		return true
	}
	var media interface{}
	var mime string
	ptt := false
	if a := quoted.GetAudioMessage(); a != nil {
		media, mime, ptt = a, a.GetMimetype(), a.GetPTT()
	} else if d := quoted.GetDocumentMessage(); d != nil && strings.HasPrefix(strings.ToLower(d.GetMimetype()), "audio/") {
		media, mime = d, d.GetMimetype()
	}
	if media == nil {
		b.send(chat, "❌ El mensaje citado no contiene un audio compatible.")
		return true
	}
	if b.client == nil || !b.client.IsConnected() {
		b.send(chat, "❌ WhatsApp está desconectado.")
		return true
	}
	b.send(chat, "⏳ Preparando el audio para el envío…")
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	var data []byte
	var err error
	switch v := media.(type) {
	case *waProto.AudioMessage:
		data, err = b.client.Download(ctx, v)
	case *waProto.DocumentMessage:
		data, err = b.client.Download(ctx, v)
	}
	cancel()
	if err != nil || len(data) == 0 {
		log.Printf("AUDIO_REENVIO_DESCARGA_ERROR | numero=%s | err=%v", clean(number), err)
		b.send(chat, "❌ No pude descargar el audio citado.")
		return true
	}
	var recipients []string
	switch mode {
	case "todos", "todo", "plantel":
		b.mu.Lock()
		for _, player := range b.state.Players {
			recipients = append(recipients, clean(player.Number))
		}
		b.mu.Unlock()
	case "pendientes", "pendiente":
		b.mu.Lock()
		for _, player := range b.state.Players {
			n := clean(player.Number)
			a, answered := b.state.Match.Answers[n]
			if !answered || (a.Status != "SI" && a.Status != "NO") {
				recipients = append(recipients, n)
			}
		}
		b.mu.Unlock()
	default:
		n := clean(mode)
		if len(n) >= 10 && len(n) <= 15 {
			recipients = []string{n}
		} else {
			b.send(chat, "Uso: respondé al audio con !audio todos, !audio pendientes o !audio NUMERO.")
			return true
		}
	}
	if len(recipients) == 0 {
		b.send(chat, "📭 No hay destinatarios para esa opción.")
		return true
	}
	sent, failed := 0, 0
	for _, dest := range recipients {
		if b.sendAudioToPhone(dest, data, mime, ptt) {
			sent++
		} else {
			failed++
		}
		time.Sleep(350 * time.Millisecond)
	}
	b.send(chat, fmt.Sprintf("🎧 Envío terminado. Enviados: %d | Fallidos: %d.", sent, failed))
	log.Printf("AUDIO_PLANTEL_ENVIADO | modo=%s | solicitante=%s | enviados=%d | fallidos=%d", mode, clean(number), sent, failed)
	return true
}

// handleAudioForwardNumber consume el próximo número del usuario que preparó el audio.
func (b *Bot) handleAudioForwardNumber(chat types.JID, number, body string) bool {
	if !isAdmin(number) {
		return false
	}
	key := chat.String() + "|" + clean(number)
	if clean(number) == "" {
		key = chat.String()
	}
	b.mu.Lock()
	pending, ok := b.audioForward[key]
	if ok && time.Since(pending.CreatedAt) > 5*time.Minute {
		delete(b.audioForward, key)
		ok = false
	}
	if !ok {
		b.mu.Unlock()
		return false
	}
	n := clean(strings.TrimSpace(body))
	if len(n) < 10 || len(n) > 15 || n != strings.TrimSpace(body) {
		b.mu.Unlock()
		if strings.HasPrefix(strings.TrimSpace(body), "!") || strings.HasPrefix(strings.TrimSpace(body), "?") {
			return false
		}
		b.send(chat, "⚠️ No parece un número internacional válido. Pegalo solo con dígitos, por ejemplo 54911XXXXXXXX.")
		return true
	}
	delete(b.audioForward, key)
	b.mu.Unlock()
	if b.sendAudioToPhone(n, pending.Data, pending.Mimetype, pending.PTT) {
		b.send(chat, "📨 Audio enviado a +"+n+".")
	} else {
		b.send(chat, "❌ No pude enviar el audio a +"+n+". Verificá que tenga WhatsApp y volvé a citar el audio con !audio.")
	}
	return true
}

func (b *Bot) sendAudioToPhone(number string, data []byte, mime string, ptt bool) bool {
	n := clean(number)
	if len(n) < 10 || len(n) > 15 || len(data) == 0 || b.client == nil || !b.client.IsConnected() {
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	results, err := b.client.IsOnWhatsApp(ctx, []string{"+" + n})
	if err != nil || len(results) == 0 || results[0].JID.IsEmpty() {
		log.Printf("AUDIO_REENVIO_DESTINATARIO_ERROR | numero=%s | err=%v", n, err)
		return false
	}
	dest := results[0].PhoneNumber
	if dest.IsEmpty() {
		dest = results[0].JID
	}
	if dest.Server == types.LegacyUserServer {
		dest.Server = types.DefaultUserServer
	}
	upload, err := b.client.Upload(ctx, data, whatsmeow.MediaAudio)
	if err != nil {
		log.Printf("AUDIO_REENVIO_SUBIDA_ERROR | numero=%s | err=%v", n, err)
		return false
	}
	if mime == "" {
		mime = "audio/ogg; codecs=opus"
	}
	audio := &waProto.AudioMessage{URL: proto.String(upload.URL), Mimetype: proto.String(mime), FileSHA256: upload.FileSHA256, FileEncSHA256: upload.FileEncSHA256, MediaKey: upload.MediaKey, FileLength: proto.Uint64(uint64(len(data))), DirectPath: proto.String(upload.DirectPath), PTT: proto.Bool(ptt)}
	resp, err := b.client.SendMessage(ctx, dest, &waProto.Message{AudioMessage: audio})
	if err != nil {
		log.Printf("AUDIO_REENVIO_ENVIO_ERROR | numero=%s | err=%v", n, err)
		return false
	}
	log.Printf("AUDIO_REENVIO_ENVIADO | numero=%s | destino=%s | id=%s | bytes=%d", n, resp.Chat, resp.ID, len(data))
	return true
}

func isStickerCommand(body string) bool {
	fields := strings.Fields(strings.ToLower(strings.TrimSpace(body)))
	if len(fields) == 0 {
		return false
	}
	switch strings.TrimRight(fields[0], ".,!¡¿;:") {
	case "!sticker", "!stikcer", "?sticker", "¿sticker", "sticker", "!s":
		return true
	default:
		return false
	}
}

type PendingSticker struct {
	Data      []byte
	Step      string
	CreatedAt time.Time
}

func stickerKey(chat types.JID, number string) string { return chat.String() + "|" + clean(number) }

// handleStickerCommand inicia la creación y pregunta si se agrega texto dentro de la imagen.
func (b *Bot) handleStickerCommand(chat, sender types.JID, number string, message *waProto.Message, body string) bool {
	if !isStickerCommand(body) {
		return false
	}
	var image *waProto.ImageMessage
	if message != nil {
		image = unwrapIncomingMessage(message).GetImageMessage()
	}
	if image == nil {
		if quoted := quotedMessage(message); quoted != nil {
			image = quoted.GetImageMessage()
		}
	}
	if image == nil {
		b.send(chat, "🖼️ Enviá una foto con !s, !sticker o !stikcer, o respondé a una foto con cualquiera de esos comandos.")
		return true
	}
	if b.client == nil || !b.client.IsConnected() {
		b.send(chat, "❌ WhatsApp está desconectado.")
		return true
	}
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		b.send(chat, "⚠️ Para crear stickers instalá ffmpeg: pkg install ffmpeg -y")
		return true
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	data, err := b.client.Download(ctx, image)
	cancel()
	if err != nil || len(data) == 0 {
		log.Printf("STICKER_DESCARGA_ERROR | chat=%s | err=%v", chat, err)
		b.send(chat, "❌ No pude descargar la foto para convertirla.")
		return true
	}
	if len(data) > 20*1024*1024 {
		b.send(chat, "⚠️ La foto supera los 20 MB.")
		return true
	}
	key := stickerKey(chat, number)
	b.mu.Lock()
	if b.pendingSticker == nil {
		b.pendingSticker = make(map[string]PendingSticker)
	}
	b.pendingSticker[key] = PendingSticker{Data: data, Step: "choice", CreatedAt: time.Now()}
	b.mu.Unlock()
	b.send(chat, "🖼️ ¿Querés agregar texto dentro del sticker?\n1️⃣ Sí, agregar texto\n2️⃣ No, dejar la imagen sin texto")
	return true
}

// handleStickerChoice consume la elección y, si corresponde, el texto para dibujarlo.
func (b *Bot) handleStickerChoice(chat types.JID, number, body string) bool {
	key := stickerKey(chat, number)
	b.mu.Lock()
	pending, ok := b.pendingSticker[key]
	if ok && time.Since(pending.CreatedAt) > 3*time.Minute {
		delete(b.pendingSticker, key)
		ok = false
	}
	if !ok {
		b.mu.Unlock()
		return false
	}
	text := strings.TrimSpace(body)
	if pending.Step == "choice" {
		if text != "1" && text != "2" {
			b.mu.Unlock()
			return false
		}
		if text == "1" {
			pending.Step = "text"
			pending.CreatedAt = time.Now()
			b.pendingSticker[key] = pending
			b.mu.Unlock()
			b.send(chat, "✍️ Escribí el texto que querés dentro del sticker.")
			return true
		}
		delete(b.pendingSticker, key)
		b.mu.Unlock()
		b.createSticker(chat, pending.Data, "")
		return true
	}
	if pending.Step == "text" {
		if text == "" || isBotCommand(text) {
			b.mu.Unlock()
			return false
		}
		delete(b.pendingSticker, key)
		b.mu.Unlock()
		b.createSticker(chat, pending.Data, text)
		return true
	}
	b.mu.Unlock()
	return false
}

func (b *Bot) createSticker(chat types.JID, data []byte, overlayText string) {
	if b.client == nil || !b.client.IsConnected() {
		b.send(chat, "❌ WhatsApp está desconectado.")
		return
	}
	dir, err := os.MkdirTemp("", "nexus-sticker-*")
	if err != nil {
		b.send(chat, "❌ No pude preparar el sticker.")
		return
	}
	defer os.RemoveAll(dir)
	input, output := filepath.Join(dir, "input.jpg"), filepath.Join(dir, "sticker.webp")
	if err = os.WriteFile(input, data, 0600); err != nil {
		b.send(chat, "❌ No pude guardar la foto temporalmente.")
		return
	}
	stamp := time.Now().Format("02/01/2006 15:04:05")
	label := "Sticker creado con NEXUS TITAN"
	if desc := strings.TrimSpace(overlayText); desc != "" {
		label = "Sticker: " + desc
	}
	if len([]rune(label)) > 120 {
		label = string([]rune(label)[:120])
	}
	vf := "scale=512:512:force_original_aspect_ratio=increase,crop=512:512"
	if strings.TrimSpace(overlayText) != "" {
		textPath := filepath.Join(dir, "sticker-text.txt")
		if err := os.WriteFile(textPath, []byte(overlayText), 0600); err != nil {
			b.send(chat, "❌ No pude preparar el texto del sticker.")
			return
		}
		vf += ",drawtext=textfile=" + textPath + ":fontcolor=white:fontsize=34:borderw=3:bordercolor=black:x=(w-text_w)/2:y=h-text_h-28"
	}
	var convertErr error
	var convertOutput []byte
	for _, quality := range []string{"75", "60", "45", "30", "20"} {
		cmd := exec.Command("ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", input, "-vf", vf, "-frames:v", "1", "-c:v", "libwebp", "-quality", quality, "-compression_level", "6", output)
		convertOutput, convertErr = cmd.CombinedOutput()
		if convertErr != nil {
			break
		}
		if info, statErr := os.Stat(output); statErr == nil && info.Size() <= 100*1024 {
			break
		}
	}
	if convertErr != nil {
		log.Printf("STICKER_CONVERSION_ERROR | err=%v | detalle=%s", convertErr, strings.TrimSpace(string(convertOutput)))
		b.send(chat, "❌ No pude convertir la imagen a WebP. Revisá que ffmpeg tenga soporte libwebp y drawtext.")
		return
	}
	webp, err := os.ReadFile(output)
	if err != nil || len(webp) == 0 {
		b.send(chat, "❌ No se generó el archivo WebP.")
		return
	}
	if len(webp) > 100*1024 {
		b.send(chat, "⚠️ No pude comprimir la foto al límite recomendado de 100 KB para stickers. Probá con otra imagen más simple.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	upload, err := b.client.Upload(ctx, webp, whatsmeow.MediaImage)
	if err != nil {
		cancel()
		log.Printf("STICKER_SUBIDA_ERROR | err=%v", err)
		b.send(chat, "❌ WhatsApp no permitió subir el sticker.")
		return
	}
	sticker := &waProto.StickerMessage{URL: proto.String(upload.URL), FileSHA256: upload.FileSHA256, FileEncSHA256: upload.FileEncSHA256, MediaKey: upload.MediaKey, Mimetype: proto.String("image/webp"), Height: proto.Uint32(512), Width: proto.Uint32(512), DirectPath: proto.String(upload.DirectPath), FileLength: proto.Uint64(uint64(len(webp))), StickerSentTS: proto.Int64(time.Now().Unix()), AccessibilityLabel: proto.String(label)}
	resp, err := b.client.SendMessage(ctx, chat, &waProto.Message{StickerMessage: sticker})
	cancel()
	if err != nil {
		log.Printf("STICKER_ENVIO_ERROR | chat=%s | err=%v", chat, err)
		b.send(chat, "❌ WhatsApp rechazó el sticker.")
		return
	}
	log.Printf("STICKER_CREADO | chat=%s | id=%s | bytes=%d | texto_agregado=%t | descripcion=%q", resp.Chat, resp.ID, len(webp), strings.TrimSpace(overlayText) != "", label)
	// AccessibilityLabel es una descripción accesible para lectores de pantalla; WhatsApp no garantiza mostrarla como ventana al tocar el sticker.
	// Enviamos además una descripción visible en el chat para que no dependa del cliente de WhatsApp.
	visibleDescription := "📝 Descripción del sticker: " + label + " | " + stamp
	b.send(chat, visibleDescription)
}
