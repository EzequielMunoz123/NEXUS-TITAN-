package main

import (
	"fmt"
	"strings"
	"sync"
	"sync/atomic"

	"go.mau.fi/whatsmeow/types"
)

// Motor conversacional local. No usa servicios externos, modelos remotos ni API.
// Combina detección por intención, contexto breve por persona y respuestas redactadas.
var localReplyCounter atomic.Uint64
var localContextMu sync.Mutex
var localLastIntent = map[string]string{}

var localReplies = map[string][]string{
	"seguimiento": {"Te amplío: puedo orientarte con la convocatoria y los datos que estén guardados, pero no invento información que todavía no cargaron.", "Claro, te explico un poco más. Si hablamos del partido, puedo consultar fecha, hora, cancha, costo y cupos.", "Dale. Para no confundirte, contame qué parte querés que detalle: el partido, el pago o cómo confirmar."},
	"saludo": {
		"¡Buenas! ¿Cómo andás? ⚽ Acá estoy para ayudarte con el fútbol y la organización.",
		"¡Hola, hola! ¿Todo tranquilo? Decime qué necesitás y lo vemos.",
		"¡Qué hacés! Bienvenido. ¿Hablamos del partido o querés charlar un rato?",
		"¡Buenas! Siempre hay tiempo para hablar de fútbol. ¿Qué se cuenta?",
		"¡Hola! ¿Cómo viene ese día? Si tenés alguna duda del equipo, preguntame.",
	},
	"como_estas": {"¡Todo en orden por acá, listo para organizar el próximo partido! ¿Vos cómo estás?", "Bien, con la pelota lista 😄 ¿Y vos, todo bien?", "Acá firme, ayudando al equipo. ¿Cómo viene la mano?"},
	"gracias":    {"¡No hay de qué! Para eso estoy. ⚽", "¡Un gusto! Cuando necesites algo, escribime.", "¡De nada, equipo! Que salga lindo ese partido."},
	"despedida":  {"¡Nos vemos! Que andes bien y cuidate.", "¡Hasta la próxima! Nos cruzamos en la cancha. ⚽", "Dale, hablamos después. ¡Abrazo futbolero!"},
	"fecha": {
		"La fecha del partido es %s. Si todavía no se cargó, un administrador tiene que completar la convocatoria.",
		"Tengo anotado que se juega el %s. Revisá el aviso por si hubo cambios.",
		"Según los datos guardados, la fecha es %s. Si necesitás confirmarla, consultá al administrador.",
		"El día previsto para el encuentro es %s. ¡Organizate con tiempo!",
	},
	"hora": {
		"El horario informado es %s. Revisá el mensaje de convocatoria por si hubo alguna actualización.",
		"La hora que figura para el partido es %s. Tratá de llegar unos minutos antes.",
		"Tengo guardado este horario: %s. Si se modifica, lo tiene que avisar un administrador.",
	},
	"lugar": {
		"El lugar cargado para jugar es %s. Si necesitás una ubicación más precisa, consultá al administrador.",
		"La cancha informada es %s. ¡No te olvides de revisar cómo llegar!",
		"Jugamos en %s, según la convocatoria guardada.",
	},
	"costo": {
		"El importe informado por jugador es %s. Si cambia, los administradores deben actualizar la convocatoria.",
		"Cada jugador tiene que abonar %s. Ante cualquier duda, hablá con un administrador.",
		"El costo guardado para este partido es %s por persona.",
	},
	"pago": {
		"Los medios disponibles son transferencia al alias ezzze.mzz o efectivo. Si elegís transferencia, mandá el comprobante por privado; el administrador revisa el pago.",
		"Podés pagar en efectivo el día del partido o transferir al alias ezzze.mzz. Después enviá el comprobante por privado.",
		"Para el pago tenés dos opciones: efectivo o transferencia a ezzze.mzz. La transferencia queda pendiente de revisión hasta que un administrador la controle.",
	},
	"plantel": {
		"El plantel tiene %d jugadores registrados. Para ver los nombres, un administrador puede usar !jugadores.",
		"Hay %d personas guardadas en el plantel. El listado completo lo puede consultar un administrador con !jugadores.",
		"Actualmente figuran %d jugadores en la base del equipo. El máximo de registro es 30.",
	},
	"lista": {
		"Por ahora hay %d confirmados de un máximo de 10. Para ver los nombres, rechazos y pendientes, un administrador puede usar !lista.",
		"El conteo actual marca %d confirmados. Los detalles de quién respondió los muestra !lista a los administradores.",
		"Van %d jugadores confirmados hasta ahora. Todavía puede cambiar mientras la convocatoria esté abierta.",
	},
	"cupos": {
		"Hay %d confirmados y quedan %d lugares disponibles. La convocatoria está %s.",
		"El contador va %d/10: quedan %d cupos y la lista está %s.",
		"Por ahora se anotaron %d. Restan %d lugares; la convocatoria sigue %s.",
	},
	"confirmar": {"¡Buenísimo! Para confirmar la convocatoria activa, escribí SI. Después elegí TRANSFERENCIA o EFECTIVO para indicar cómo vas a pagar."},
	"rechazar":  {"No hay problema, gracias por avisar. Para registrar que no vas, respondé NO en la convocatoria."},
	"cambiar":   {"Si la convocatoria sigue abierta, podés cambiar tu respuesta escribiendo SI o NO. Si ya cerró, el administrador tendrá que ayudarte."},
	"reglas":    {"La convocatoria funciona así: respondés SI o NO; si confirmás, elegís el medio de pago. El cupo es de 10. Se cierra al completarse o 20 minutos antes del inicio. La respuesta vence a las 5 horas."},
	"futbol": {
		"El fútbol tiene eso: podés jugar bien, mal o regular, pero lo importante es meterle ganas y disfrutar con el equipo. ⚽",
		"Un buen equipo no se arma solamente con cracks: hace falta compromiso, respeto y llegar a horario.",
		"La pelota no se mancha 😄 ¿Sos de jugar atrás, en el medio o arriba?",
		"En el fútbol siempre hay revancha. Lo importante es no dejar de correr y jugar en equipo.",
	},
	"posicion":      {"¡Bien ahí! Cada puesto tiene su trabajo. Lo importante es hablarse, marcar y darle una opción al compañero."},
	"resultado":     {"Todavía no tengo cargado un resultado oficial. No quiero inventarte un marcador; consultá con los administradores cuando termine el partido."},
	"ganar_perder":  {"Ganar está buenísimo, pero también cuenta cómo se juega. Si el equipo se banca y vuelve a intentar, ya hay algo para rescatar."},
	"motivacion":    {"¡Vamos equipo! A poner ganas, correr por el compañero y no bajar los brazos. 💪⚽", "La actitud también juega: concentración, compañerismo y a dejar todo en la cancha.", "Un partido se gana jugando juntos. ¡A meterle con todo!"},
	"broma":         {"Jajaja, pará que todavía no empezó el partido y ya estamos haciendo tiempo 😂", "¡Esa estuvo buena! Guardá un poco de energía para la cancha 😄", "Yo pongo la charla, ustedes pongan los goles 😂⚽"},
	"enojo":         {"Tranqui, hablemos bien y lo resolvemos. Si el problema es con la convocatoria o el pago, puedo orientarte; para decisiones del equipo hablá con un administrador."},
	"aburrido":      {"Podemos hablar de fútbol 😄 ¿Qué preferís: una charla de posiciones, equipos, jugadas o alguna anécdota de cancha?"},
	"clima":         {"No tengo acceso al clima en vivo, así que no te voy a inventar si llueve o hace calor. Revisá el pronóstico antes de salir y confirmá con el grupo si se juega."},
	"demora":        {"Si vas a llegar tarde, avisale cuanto antes a un administrador o al grupo. Así pueden organizar los equipos."},
	"lesion":        {"Uh, ojalá te mejores pronto. No fuerces una lesión para jugar; avisale al administrador si no vas a poder asistir."},
	"equipo":        {"Para que salga bien, lo mejor es confirmar a tiempo, respetar los horarios y avisar si surge algún cambio."},
	"horario":       {"Tratemos de llegar unos minutos antes para cambiarnos y organizar los equipos sin apuro."},
	"llevar":        {"Llevá ropa deportiva, calzado adecuado, agua y el importe acordado. Si necesitás algo especial, confirmalo con el administrador."},
	"encuentro":     {"El punto de encuentro se confirma con el administrador. No tengo un punto adicional cargado y prefiero no inventarlo."},
	"saludo_equipo": {"¡Vamos ese equipo! Que no falte el compañerismo, las ganas y el tercer tiempo 😄⚽"},
	"menu":          {"Puedo ayudarte con datos del partido, fecha, hora, cancha, costo, pagos, cupos, confirmación y algunas charlas de fútbol. Para ver los comandos, escribí !menu."},
	"desconocido": {
		"Te leo 😄 Puedo charlar de fútbol, del equipo o ayudarte con la convocatoria. ¿Qué tenés en mente?",
		"No terminé de captar la idea. Contámelo de otra manera, no hace falta escribirlo como comando.",
		"A ver si te sigo: ¿me estás preguntando por el partido, querés hablar de fútbol o es otro tema?",
		"Estoy para conversar, aunque no sé responder cualquier tema como una persona. Probá explicarme un poquito más.",
		"¡Dale, contame un poco más! Si es sobre fecha, cancha, horario, precio o pagos, te paso lo que esté guardado.",
	},
}

func containsAny(s string, words ...string) bool {
	for _, word := range words {
		if strings.Contains(s, word) {
			return true
		}
	}
	return false
}

func detectLocalIntent(text string) string {
	s := normalize(strings.TrimSpace(text))
	s = strings.Trim(s, " .,!¡?¿;:()[]{}\n\t")
	switch {
	case containsAny(s, "contame mas", "explicame", "como asi", "y eso", "por que", "decime mas", "segui", "continua"):
		return "seguimiento"
	case containsAny(s, "muchas gracias", "te agradezco", "gracias", "joya gracias", "mil gracias"):
		return "gracias"
	case containsAny(s, "hasta luego", "nos vemos", "chau", "adios", "me voy", "hasta mañana"):
		return "despedida"
	case containsAny(s, "como estas", "como andas", "todo bien", "como va todo", "que tal estas"):
		return "como_estas"
	case containsAny(s, "hola", "buen dia", "buenas", "que onda", "que haces", "holi"):
		return "saludo"
	case containsAny(s, "cuando es", "que dia", "fecha", "cuando jugamos", "dia del partido"):
		return "fecha"
	case containsAny(s, "a que hora", "horario", "que hora", "hora del partido", "cuando arrancamos"):
		return "hora"
	case containsAny(s, "donde jugamos", "donde es", "que cancha", "cancha", "ubicacion", "direccion", "lugar del partido"):
		return "lugar"
	case containsAny(s, "cuanto sale", "cuanto cuesta", "cuanto es", "precio", "importe", "valor", "plata por jugador"):
		return "costo"
	case containsAny(s, "como pago", "alias", "transferencia", "efectivo", "comprobante", "pagar"):
		return "pago"
	case containsAny(s, "plantel", "jugadores registrados", "lista de jugadores", "quienes estan anotados"):
		return "plantel"
	case containsAny(s, "quienes juegan", "quienes confirmaron", "confirmados", "pendientes", "lista"):
		return "lista"
	case containsAny(s, "queda lugar", "hay lugar", "hay cupo", "cuantos lugares", "cupo", "lleno"):
		return "cupos"
	case containsAny(s, "anotame", "me anoto", "quiero jugar", "voy a jugar", "confirmar", "cuenta conmigo"):
		return "confirmar"
	case containsAny(s, "no puedo", "no voy", "no juego", "baja", "darme de baja"):
		return "rechazar"
	case containsAny(s, "cambiar respuesta", "cambie de opinion", "ahora si", "ahora no", "modificar respuesta"):
		return "cambiar"
	case containsAny(s, "reglas", "como funciona", "como se confirma", "como es la convocatoria"):
		return "reglas"
	case containsAny(s, "resultado", "cuanto salimos", "como salimos", "marcador", "quien gano"):
		return "resultado"
	case containsAny(s, "ganamos", "perdimos", "empate", "jugamos mal", "jugamos bien"):
		return "ganar_perder"
	case containsAny(s, "motivame", "vamos equipo", "vamos muchachos", "fuerza equipo", "a ganar"):
		return "motivacion"
	case containsAny(s, "llueve", "clima", "pronostico", "va a llover", "hace frio", "hace calor"):
		return "clima"
	case containsAny(s, "llego tarde", "voy tarde", "demorado", "demora", "estoy llegando"):
		return "demora"
	case containsAny(s, "lesione", "me duele", "estoy lesionado", "me lastime", "dolor"):
		return "lesion"
	case containsAny(s, "que llevo", "llevar", "llevo algo", "botines", "ropa deportiva", "agua"):
		return "llevar"
	case containsAny(s, "donde nos juntamos", "punto de encuentro", "nos encontramos"):
		return "encuentro"
	case containsAny(s, "aburrido", "no hay nada", "que hacemos", "charlemos"):
		return "aburrido"
	case containsAny(s, "jaj", "jeje", "😂", "🤣", "chiste", "broma"):
		return "broma"
	case containsAny(s, "enojado", "bronca", "molesto", "que problema", "no me gusta"):
		return "enojo"
	case containsAny(s, "delantero", "arquero", "portero", "defensor", "mediocampo", "volante", "posicion"):
		return "posicion"
	case containsAny(s, "futbol", "pelota", "gol", "cancha", "partido", "equipo", "jugador"):
		return "futbol"
	case containsAny(s, "llegar temprano", "puntual", "a tiempo"):
		return "horario"
	case containsAny(s, "menu", "ayuda", "comandos", "que podes hacer", "que puedes hacer"):
		return "menu"
	case containsAny(s, "como va el partido", "estado del partido", "como estamos", "cuantos somos"):
		return "lista"
	default:
		return "desconocido"
	}
}

func chooseLocalReply(key, intent string, options []string) string {
	if len(options) == 0 {
		return "Contame un poco más y trato de ayudarte."
	}
	localContextMu.Lock()
	defer localContextMu.Unlock()
	idx := localReplyCounter.Add(1) - 1
	if intent != "seguimiento" {
		localLastIntent[key] = intent
	}
	return options[idx%uint64(len(options))]
}

func (b *Bot) replyLocal(to types.JID, number, userText string) {
	b.mu.Lock()
	m := b.state.Match
	confirmed := b.confirmedCount()
	registered := len(b.state.Players)
	active := m.Active
	b.mu.Unlock()

	intent := detectLocalIntent(userText)
	options := localReplies[intent]
	if len(options) == 0 {
		options = localReplies["desconocido"]
	}
	body := chooseLocalReply(number, intent, options)
	switch intent {
	case "seguimiento":
		localContextMu.Lock()
		last := localLastIntent[number]
		localContextMu.Unlock()
		if last == "fecha" && m.Day != "" {
			body = "La fecha que figura en la convocatoria es " + m.Day + ". Si cambió, tiene que actualizarla un administrador."
		}
		if last == "hora" && m.Hour != "" {
			body = "El horario guardado es " + m.Hour + ". Te recomiendo llegar unos minutos antes."
		}
		if last == "lugar" && m.Place != "" {
			body = "La cancha o lugar cargado es " + m.Place + ". Para una dirección exacta, consultá al administrador."
		}
		if last == "costo" && m.Cost != "" {
			body = "El costo informado es " + m.Cost + " por jugador."
		}
	case "fecha":
		if m.Name != "" && strings.TrimSpace(m.Day) != "" {
			body = fmt.Sprintf(body, m.Day)
		} else {
			body = "Todavía no hay una fecha cargada. Cuando se cree la convocatoria, voy a poder informártela."
		}
	case "hora":
		if m.Name != "" && strings.TrimSpace(m.Hour) != "" {
			body = fmt.Sprintf(body, m.Hour)
		} else {
			body = "Todavía no hay un horario cargado para el partido."
		}
	case "lugar":
		if m.Name != "" && strings.TrimSpace(m.Place) != "" {
			body = fmt.Sprintf(body, m.Place)
		} else {
			body = "Todavía no hay una cancha cargada para el partido."
		}
	case "costo":
		if m.Name != "" && strings.TrimSpace(m.Cost) != "" {
			body = fmt.Sprintf(body, m.Cost)
		} else {
			body = "Todavía no está cargado el importe por jugador."
		}
	case "plantel":
		body = fmt.Sprintf(body, registered)
	case "lista":
		if m.Name == "" {
			body = "📭 No hay partidos programados."
		} else {
			body = fmt.Sprintf(body, confirmed)
		}
	case "cupos":
		libres := 10 - confirmed
		if libres < 0 {
			libres = 0
		}
		estado := "cerrada"
		if active {
			estado = "abierta"
		}
		body = fmt.Sprintf(body, confirmed, libres, estado)
	case "pago":
		if m.Name == "" {
			body = "No hay una convocatoria activa. Cuando se abra, el bot te indicará cómo pagar."
		}
	case "confirmar":
		if !active {
			body = "Ahora no hay una convocatoria abierta. Esperá el mensaje de los administradores para responder SI o NO."
		}
	case "cambiar":
		if !active {
			body = "La convocatoria está cerrada. Ya no se pueden modificar las respuestas de este partido."
		}
	}
	_ = number
	b.send(to, body)
}
