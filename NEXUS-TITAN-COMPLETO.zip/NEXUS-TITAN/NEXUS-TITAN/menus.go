package main

import (
	"strings"
	"unicode"
)

func menuResponse(raw string, admin bool) (string, bool) {
	raw = strings.Map(func(r rune) rune {
		if unicode.Is(unicode.Cf, r) || r == '\uFEFF' {
			return -1
		}
		return r
	}, raw)
	fields := strings.Fields(strings.ToLower(strings.TrimSpace(raw)))
	if len(fields) == 0 {
		return "", false
	}
	cmd := strings.TrimRight(fields[0], ".,!¡¿;:()[]{}<>\"'`")
	cmd = strings.ReplaceAll(cmd, " ", "")
	if at := strings.IndexByte(cmd, '@'); at > 0 {
		cmd = cmd[:at]
	}
	switch cmd {
	case "!menu", "/menu", ".menu", "menu", "!ayuda", "/ayuda", "ayuda", "!help", "/help", "help", "?", "?menu":
		return menuText(admin, false), true
	case "!allmenu", "/allmenu", "allmenu", "!menucompleto", "/menucompleto", "menucompleto", "!allm", "/allm", "allm":
		return menuText(admin, true), true
	default:
		return "", false
	}
}

func menuText(admin, full bool) string {
	var b strings.Builder
	b.WriteString("⚡ *NEXUS TITAN — MENÚ*\n━━━━━━━━━━━━━━━━━━\n")
	b.WriteString("🌐 *COMANDOS PARA TODOS*\n")
	b.WriteString("• !menu o ? — abrir este menú\n• !lista / !partidos — ver convocatoria\n• !jugadores / !listalista — consultar listas\n• Responder SI o NO — confirmar asistencia si estás convocado\n")
	b.WriteString("\n📥 *DESCARGAS — TIKTOK / YOUTUBE / INSTAGRAM*\n• TikTok: !tiktok ENLACE (también ?tiktok)\n• YouTube: !youtube ENLACE (también ?youtube)\n• Instagram: !instagram ENLACE (también ?instagram)\n• Al enviar solo el enlace, NEXUS pregunta el formato: 1️⃣ MP3 (audio) o 2️⃣ MP4 (video).\n• Para descargar directo, agregá MP3 o MP4 al final. Ejemplo: !youtube https://youtu.be/xxxxx mp3\n• Alias disponibles: !tt / ?tt, !yt / ?yt, !ig / ?ig\n")
	b.WriteString("\n🎨 *STICKERS Y AUDIOS*\n• Crear sticker: enviá una foto con !sticker o ?sticker en el comentario, o respondé a una foto con !sticker / ?sticker.\n• El sticker incluye los datos de NEXUS TITAN y se envía una ficha visible con fecha, hora y creador.\n• El bot también puede reaccionar aleatoriamente a notas de voz y archivos de audio.\n")
	b.WriteString("\n🤖 *IA Y JUEGOS*\n• !gemini PREGUNTA / !deepseek PREGUNTA — consultar IA\n• !perfil / !fantasymy — perfil\n• !balance / !monedas — saldo\n• !daily — recompensa diaria\n• !work — trabajar\n• !top / !leaderboard — ranking\n")
	b.WriteString("\n💳 *PAGOS*\n• TRANSFERENCIA — alias ezzze.mzz; luego enviar comprobante\n• EFECTIVO — pago en mano\n")
	if admin {
		b.WriteString("\n👑 *SOLO ADMINISTRADORES*\n")
		b.WriteString("• !partido — crear convocatoria\n• !sacar NUMERO — quitar solo de la lista del partido, sin eliminar del plantel\n• !audio todos / pendientes / NUMERO — reenviar audio (solo administradores)\n• !cancelar — cancelar convocatoria\n• !finalizar — cerrar y limpiar partido\n• !agregar / !quitar — modificar plantel\n• !agregarlista / !quitarlista — modificar lista auxiliar\n• !confirmarpago NUMERO / !rechazarpago NUMERO — revisar pagos\n• !ultimos 20 NUMERO / !responder — historial y respuestas\n• !ia on / !ia off / !ia estado — controlar IA automática\n• !mensaje — avisar al plantel\n• !bloquear / !desbloquear / !bloqueados\n• !modocharla / !callate / !llegotupapariber\n• !atras — cancelar paso administrativo\n")
	} else {
		b.WriteString("\n🔒 Las funciones de administración solo aparecen para administradores y no se pueden ejecutar con una cuenta común.\n")
	}
	if full {
		b.WriteString("\nℹ️ *SISTEMA*\n• Motor: Go + whatsmeow\n• Cupo por partido: 10 confirmados\n• Plantel máximo: 30 jugadores\n")
	}
	b.WriteString("━━━━━━━━━━━━━━━━━━\nEscribí !menu o ? para volver a abrir el menú.")
	return b.String()
}
