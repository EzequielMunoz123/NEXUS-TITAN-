package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"sort"
	"strings"
	"time"

	waProto "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/types"
)

const historyFile = "historial-mensajes.json"

type StoredMessage struct {
	ID     string    `json:"id"`
	Number string    `json:"numero"`
	Chat   string    `json:"chat"`
	Body   string    `json:"texto"`
	At     time.Time `json:"fecha"`
}

type geminiRequest struct {
	SystemInstruction struct {
		Parts []geminiPart `json:"parts"`
	} `json:"systemInstruction"`
	Contents         []geminiContent `json:"contents"`
	GenerationConfig struct {
		Temperature     float64 `json:"temperature"`
		MaxOutputTokens int     `json:"maxOutputTokens"`
	} `json:"generationConfig"`
}
type geminiContent struct {
	Role  string       `json:"role"`
	Parts []geminiPart `json:"parts"`
}
type geminiPart struct {
	Text string `json:"text"`
}
type chatMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}
type geminiResponse struct {
	Candidates []struct {
		Content struct {
			Parts []geminiPart `json:"parts"`
		} `json:"content"`
		FinishReason string `json:"finishReason"`
	} `json:"candidates"`
	Error struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
		Status  string `json:"status"`
	} `json:"error"`
}

func (b *Bot) loadHistory() {
	data, err := os.ReadFile(historyFile)
	if err != nil {
		return
	}
	var all []StoredMessage
	if json.Unmarshal(data, &all) != nil {
		return
	}
	b.history = map[string][]StoredMessage{}
	for _, item := range all {
		key := clean(item.Number)
		if key != "" {
			b.history[key] = append(b.history[key], item)
		}
	}
}
func (b *Bot) saveHistoryLocked() {
	all := make([]StoredMessage, 0)
	for _, items := range b.history {
		all = append(all, items...)
	}
	sort.Slice(all, func(i, j int) bool { return all[i].At.Before(all[j].At) })
	if len(all) > 3000 {
		all = all[len(all)-3000:]
	}
	data, err := json.MarshalIndent(all, "", "  ")
	if err == nil {
		_ = os.WriteFile(historyFile, data, 0600)
	}
}
func (b *Bot) rememberMessage(number, chat, id, body string, at time.Time) {
	if strings.TrimSpace(body) == "" || clean(number) == "" {
		return
	}
	if at.IsZero() {
		at = time.Now()
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.history == nil {
		b.history = map[string][]StoredMessage{}
	}
	key := clean(number)
	items := b.history[key]
	for _, item := range items {
		if id != "" && item.ID == id {
			return
		}
	}
	items = append(items, StoredMessage{ID: id, Number: key, Chat: chat, Body: body, At: at})
	if len(items) > 100 {
		items = items[len(items)-100:]
	}
	b.history[key] = items
	b.saveHistoryLocked()
}
func (b *Bot) recentMessages(number string, limit int) []StoredMessage {
	b.mu.Lock()
	defer b.mu.Unlock()
	items := append([]StoredMessage(nil), b.history[clean(number)]...)
	if limit < 1 || limit > 50 {
		limit = 20
	}
	if len(items) > limit {
		items = items[len(items)-limit:]
	}
	for i, j := 0, len(items)-1; i < j; i, j = i+1, j-1 {
		items[i], items[j] = items[j], items[i]
	}
	return items
}
func (b *Bot) sendRecentMessages(to types.JID, number string, limit int) {
	items := b.recentMessages(number, limit)
	if len(items) == 0 {
		b.send(to, "📭 No tengo mensajes guardados de ese número todavía.")
		return
	}
	var out strings.Builder
	fmt.Fprintf(&out, "🗂️ *ÚLTIMOS %d MENSAJES*\n📱 %s\n\n", len(items), number)
	for i, item := range items {
		fmt.Fprintf(&out, "*%d.* [%s]\n%s\n\n", i+1, item.At.Local().Format("02/01 15:04"), item.Body)
	}
	b.send(to, out.String())
}

// replyIndexedMessage responde en privado al autor del mensaje numerado de !ultimos.
// El índice 1 corresponde al mensaje más reciente, igual que en sendRecentMessages.
func (b *Bot) replyIndexedMessage(to types.JID, number string, index int, body string) {
	if index < 1 {
		b.send(to, "⚠️ El número de mensaje debe ser mayor que cero.")
		return
	}
	if strings.TrimSpace(body) == "" {
		b.send(to, "✍️ Escribí el texto después del número. Ejemplo: !responder 1 Hola.")
		return
	}
	items := b.recentMessages(number, 50)
	if index > len(items) {
		b.send(to, fmt.Sprintf("⚠️ Ese número no existe. Hay %d mensajes guardados de %s.", len(items), number))
		return
	}
	target := items[index-1]
	if !b.sendToPhone(target.Number, body) {
		b.send(to, "⚠️ No pude enviar la respuesta a "+target.Number+".")
		return
	}
	b.send(to, fmt.Sprintf("✅ Respuesta enviada a %s (mensaje %d).", target.Number, index))
}

func (b *Bot) replyQuotedMessage(to types.JID, quotedID, body string) bool {
	if quotedID == "" {
		b.send(to, "↩️ Para responder, citá primero el mensaje de WhatsApp y escribí !responder seguido del texto.")
		return true
	}
	var target StoredMessage
	found := false
	b.mu.Lock()
	for _, items := range b.history {
		for _, item := range items {
			if item.ID == quotedID {
				target = item
				found = true
				break
			}
		}
		if found {
			break
		}
	}
	b.mu.Unlock()
	if !found {
		b.send(to, "⚠️ No encuentro ese mensaje en el historial. Pedí !ultimos 20 NUMERO y volvé a citarlo.")
		return true
	}
	if strings.TrimSpace(body) == "" {
		b.send(to, "✍️ Escribí el texto después de !responder.")
		return true
	}
	if !b.sendToPhone(target.Number, body) {
		b.send(to, "⚠️ No pude enviar la respuesta a "+target.Number+".")
		return true
	}
	b.send(to, "✅ Respuesta enviada a "+target.Number+".")
	return true
}
func (b *Bot) handleIACommand(from types.JID, number, body string) bool {
	fields := strings.Fields(strings.TrimSpace(body))
	if len(fields) == 0 || !isAdmin(number) {
		return false
	}
	if normalize(fields[0]) != "!ia" {
		return false
	}
	if len(fields) < 2 {
		b.send(from, "🤖 IA automática: !ia on | !ia off | !ia estado | !ia limpiar NUMERO\nPara consultar manualmente: !ia tu pregunta")
		return true
	}
	switch normalize(fields[1]) {
	case "on", "activar":
		b.mu.Lock()
		b.state.AutoAI = true
		// Limpiar cualquier flujo administrativo pendiente: si quedó, consumía
		// mensajes normales (por ejemplo "Hola") antes de llegar a la IA.
		delete(b.flow, clean(number))
		delete(b.temp, clean(number))
		b.save()
		b.mu.Unlock()
		b.send(from, "✅ Respuestas automáticas con IA ACTIVADAS para chats privados.")
		return true
	case "off", "apagar":
		b.mu.Lock()
		b.state.AutoAI = false
		delete(b.flow, clean(number))
		delete(b.temp, clean(number))
		b.save()
		b.mu.Unlock()
		b.send(from, "🤐 Respuestas automáticas con IA DESACTIVADAS.")
		return true
	case "estado":
		b.mu.Lock()
		enabled := b.state.AutoAI
		b.mu.Unlock()
		status := "DESACTIVADA"
		if enabled {
			status = "ACTIVADA"
		}
		b.send(from, "🤖 IA automática: "+status+"\nProveedores en orden: Gemini → ChatGPT → Perplexity (solo se usa el siguiente si el anterior falla).")
		return true
	case "limpiar":
		if len(fields) < 3 {
			b.send(from, "Indicá el número: !ia limpiar 549XXXXXXXXX")
			return true
		}
		b.mu.Lock()
		delete(b.aiContext, clean(fields[2]))
		b.mu.Unlock()
		b.send(from, "🧹 Contexto de IA reiniciado para "+clean(fields[2])+".")
		return true
	default:
		return false
	}
}

// La IA automática usa proveedores en cascada: Gemini -> OpenAI -> Perplexity.
// Cada proveedor se consulta solo si el anterior falla. Solo se envía un mensaje
// a WhatsApp: la primera respuesta válida. Las claves se leen del entorno.

type openAIMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}
type openAIRequest struct {
	Model       string          `json:"model"`
	Messages    []openAIMessage `json:"messages"`
	Temperature float64         `json:"temperature,omitempty"`
	MaxTokens   int             `json:"max_tokens,omitempty"`
}
type openAIResponse struct {
	Choices []struct {
		Message openAIMessage `json:"message"`
	} `json:"choices"`
	Error struct {
		Message string `json:"message"`
	} `json:"error"`
}

func buildAIHistory(systemPrompt string, ctx []chatMessage, prompt string) []openAIMessage {
	messages := []openAIMessage{{Role: "system", Content: systemPrompt}}
	if len(ctx) > 12 {
		ctx = ctx[len(ctx)-12:]
	}
	for _, msg := range ctx {
		role := "user"
		if msg.Role == "assistant" || msg.Role == "model" {
			role = "assistant"
		}
		messages = append(messages, openAIMessage{Role: role, Content: msg.Content})
	}
	return append(messages, openAIMessage{Role: "user", Content: prompt})
}

func callGeminiAI(client *http.Client, key, model, systemPrompt string, ctx []chatMessage, prompt string) (string, error) {
	if key == "" {
		return "", fmt.Errorf("GEMINI_API_KEY no configurada")
	}
	if model == "" {
		model = "gemini-2.5-flash-lite"
	}
	body := geminiRequest{}
	body.SystemInstruction.Parts = []geminiPart{{Text: systemPrompt}}
	body.GenerationConfig.Temperature = 0.8
	body.GenerationConfig.MaxOutputTokens = 700
	if len(ctx) > 12 {
		ctx = ctx[len(ctx)-12:]
	}
	for _, msg := range ctx {
		role := "user"
		if msg.Role == "assistant" || msg.Role == "model" {
			role = "model"
		}
		body.Contents = append(body.Contents, geminiContent{Role: role, Parts: []geminiPart{{Text: msg.Content}}})
	}
	body.Contents = append(body.Contents, geminiContent{Role: "user", Parts: []geminiPart{{Text: prompt}}})
	payload, err := json.Marshal(body)
	if err != nil {
		return "", fmt.Errorf("armar solicitud Gemini: %w", err)
	}
	endpoint := "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"
	req, err := http.NewRequest(http.MethodPost, endpoint, bytes.NewReader(payload))
	if err != nil {
		return "", err
	}
	req.Header.Set("x-goog-api-key", key)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("conexión Gemini: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		data, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
		return "", fmt.Errorf("Gemini HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(data)))
	}
	var result geminiResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("respuesta Gemini inválida: %w", err)
	}
	var answer strings.Builder
	if len(result.Candidates) > 0 {
		for _, part := range result.Candidates[0].Content.Parts {
			answer.WriteString(part.Text)
		}
	}
	if text := strings.TrimSpace(answer.String()); text != "" {
		return text, nil
	}
	return "", fmt.Errorf("Gemini devolvió una respuesta vacía")
}

func callCompatibleAI(client *http.Client, provider, key, endpoint, model, systemPrompt string, ctx []chatMessage, prompt string) (string, error) {
	if key == "" {
		return "", fmt.Errorf("clave %s no configurada", provider)
	}
	body := openAIRequest{Model: model, Messages: buildAIHistory(systemPrompt, ctx, prompt), Temperature: 0.8, MaxTokens: 700}
	payload, err := json.Marshal(body)
	if err != nil {
		return "", fmt.Errorf("armar solicitud %s: %w", provider, err)
	}
	req, err := http.NewRequest(http.MethodPost, endpoint, bytes.NewReader(payload))
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+key)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("conexión %s: %w", provider, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		data, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
		return "", fmt.Errorf("%s HTTP %d: %s", provider, resp.StatusCode, strings.TrimSpace(string(data)))
	}
	var result openAIResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("respuesta %s inválida: %w", provider, err)
	}
	if len(result.Choices) == 0 || strings.TrimSpace(result.Choices[0].Message.Content) == "" {
		return "", fmt.Errorf("%s devolvió una respuesta vacía", provider)
	}
	return strings.TrimSpace(result.Choices[0].Message.Content), nil
}

func (b *Bot) replyGemini(to types.JID, number, prompt string) {
	log.Printf("IA_AUTO_INICIO | numero=%s | destino=%s | caracteres=%d", clean(number), to, len(prompt))
	b.mu.Lock()
	if b.aiContext == nil {
		b.aiContext = map[string][]chatMessage{}
	}
	ctx := append([]chatMessage(nil), b.aiContext[clean(number)]...)
	b.mu.Unlock()

	systemPrompt := `Sos NEXUS TITAN, un compañero de conversación para WhatsApp. Tu personalidad es divertida, espontánea, cercana y con humor, al estilo de un chatbot entretenido como GataBot, pero con identidad propia. Hablás principalmente en español argentino natural (vos, querés, dale), usás emojis con moderación y no sonás como un asistente corporativo.

REGLAS DE CONVERSACIÓN:
- Seguí el hilo usando los mensajes anteriores del contexto. Interpretá respuestas cortas como "sí", "no", "ok", "dale", "eso", "otro tema" según lo que se venía hablando; no preguntes de nuevo lo que ya quedó claro.
- Si la persona dice que quiere cambiar de tema, aceptalo y preguntá qué tiene ganas de charlar, sin volver al tema anterior.
- No repitas saludos ni preguntas genéricas en cada turno. Contestá directamente a lo último que dijo la persona.
- Si no entendés algo, hacé UNA pregunta concreta y breve.
- Podés conversar sobre temas generales, hacer bromas y seguir charlas casuales. No te limites al fútbol ni a las funciones del bot.
- No inventes resultados, fechas, precios, pagos ni acciones del bot. Para operaciones reales, indicá el comando correspondiente o aclarà que no podés ejecutarlas desde una charla.
- No digas que no podés hablar de cualquier tema; respondé normalmente dentro de tus conocimientos y límites.
- Mantené respuestas naturales y no demasiado largas, salvo que te pidan detalle.`

	// Timeouts independientes: si un proveedor se cuelga, se pasa al siguiente.
	client := &http.Client{Timeout: 35 * time.Second}
	providers := []struct {
		name string
		call func() (string, error)
	}{
		{"Gemini", func() (string, error) {
			return callGeminiAI(client, strings.TrimSpace(os.Getenv("GEMINI_API_KEY")), strings.TrimSpace(os.Getenv("GEMINI_MODEL")), systemPrompt, ctx, prompt)
		}},
		{"ChatGPT", func() (string, error) {
			model := strings.TrimSpace(os.Getenv("OPENAI_MODEL"))
			if model == "" {
				model = "gpt-4o-mini"
			}
			return callCompatibleAI(client, "ChatGPT", strings.TrimSpace(os.Getenv("OPENAI_API_KEY")), "https://api.openai.com/v1/chat/completions", model, systemPrompt, ctx, prompt)
		}},
		{"Perplexity", func() (string, error) {
			model := strings.TrimSpace(os.Getenv("PERPLEXITY_MODEL"))
			if model == "" {
				model = "sonar"
			}
			return callCompatibleAI(client, "Perplexity", strings.TrimSpace(os.Getenv("PERPLEXITY_API_KEY")), "https://api.perplexity.ai/chat/completions", model, systemPrompt, ctx, prompt)
		}},
	}

	var answerText, usedProvider string
	for _, provider := range providers {
		answer, err := provider.call()
		if err != nil {
			// Nunca enviar errores intermedios al chat; solo registrar y continuar.
			log.Printf("IA_FALLBACK | proveedor=%s | numero=%s | error=%v", provider.name, clean(number), err)
			continue
		}
		answerText, usedProvider = strings.TrimSpace(answer), provider.name
		if answerText != "" {
			break
		}
	}
	if answerText == "" {
		log.Printf("IA_ERROR_FINAL | numero=%s | proveedores=Gemini,ChatGPT,Perplexity", clean(number))
		b.send(to, "⚠️ En este momento no pude obtener respuesta de ninguno de mis servicios de IA. Probá de nuevo en unos minutos.")
		return
	}
	if len([]rune(answerText)) > 5000 {
		answerText = string([]rune(answerText)[:5000]) + "…"
	}
	b.mu.Lock()
	b.aiContext[clean(number)] = append(ctx, chatMessage{Role: "user", Content: prompt}, chatMessage{Role: "assistant", Content: answerText})
	if len(b.aiContext[clean(number)]) > 14 {
		b.aiContext[clean(number)] = b.aiContext[clean(number)][len(b.aiContext[clean(number)])-14:]
	}
	b.mu.Unlock()
	log.Printf("IA_AUTO_RESPUESTA | proveedor=%s | numero=%s | caracteres=%d", usedProvider, clean(number), len(answerText))
	b.send(to, answerText)
}

// quotedStanzaID obtiene el identificador del mensaje citado por WhatsApp.
func quotedStanzaID(msg *waProto.Message) string {
	msg = unwrapIncomingMessage(msg)
	if msg == nil {
		return ""
	}
	if ext := msg.GetExtendedTextMessage(); ext != nil && ext.GetContextInfo() != nil {
		return ext.GetContextInfo().GetStanzaID()
	}
	return ""
}
