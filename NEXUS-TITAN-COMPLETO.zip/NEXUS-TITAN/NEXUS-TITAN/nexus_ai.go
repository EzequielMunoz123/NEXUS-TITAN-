package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"go.mau.fi/whatsmeow/types"
)

type nexusAIResponse struct {
	Result string `json:"result"`
}

func parseNexusAICommand(body string) (string, string, bool) {
	s := strings.TrimSpace(body)
	lower := strings.ToLower(s)
	for _, prefix := range []string{"!deepseek ", ".deepseek ", "/deepseek "} {
		if strings.HasPrefix(lower, prefix) {
			return "deepseek", strings.TrimSpace(s[len(prefix):]), true
		}
	}
	for _, cmd := range []string{"!gemini", ".gemini", "/gemini", "!bard", ".bard", "/bard", "!ia", ".ia", "/ia"} {
		if lower == cmd || strings.HasPrefix(lower, cmd+" ") {
			return "gemini", strings.TrimSpace(s[len(cmd):]), true
		}
	}
	return "", "", false
}

// replyNexusAI usa los mismos proveedores públicos que aparecen en los plugins
// Gemini/DeepSeek de GataBot. No reutiliza claves privadas incrustadas en ese proyecto.
func (b *Bot) replyNexusAI(to types.JID, provider, prompt string) {
	if prompt == "" {
		b.send(to, "🤖 Escribí una consulta después del comando.\nEjemplo: !gemini explicame la fotosíntesis\nTambién podés usar !deepseek.")
		return
	}
	b.send(to, "🤖 NEXUS TITAN está pensando...")
	client := &http.Client{Timeout: 45 * time.Second}
	var endpoint string
	switch provider {
	case "deepseek":
		endpoint = "https://archive-ui.tanakadomp.biz.id/ai/deepseek?text=" + url.QueryEscape(prompt)
	default:
		endpoint = "https://apis-starlights-team.koyeb.app/starlight/gemini?text=" + url.QueryEscape(prompt)
	}
	req, err := http.NewRequest("GET", endpoint, nil)
	if err != nil {
		b.send(to, "⚠️ No pude preparar la consulta de IA.")
		return
	}
	req.Header.Set("User-Agent", "NEXUS-TITAN/1.0")
	resp, err := client.Do(req)
	if err != nil {
		b.send(to, "⚠️ El servicio de IA no respondió. Probá nuevamente más tarde.")
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		b.send(to, fmt.Sprintf("⚠️ El proveedor de IA respondió con HTTP %d.", resp.StatusCode))
		return
	}
	var data nexusAIResponse
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil || strings.TrimSpace(data.Result) == "" {
		b.send(to, "⚠️ El proveedor de IA devolvió una respuesta vacía o incompatible.")
		return
	}
	answer := strings.TrimSpace(data.Result)
	if len([]rune(answer)) > 6000 {
		answer = string([]rune(answer)[:6000]) + "\n\n…respuesta recortada."
	}
	b.send(to, "🤖 *NEXUS TITAN · "+strings.ToUpper(provider)+"*\n\n"+answer)
}
