package main

import (
	"bytes"
	"context"
	"log"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"go.mau.fi/whatsmeow"
	waProto "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/types"
	"google.golang.org/protobuf/proto"
)

const maxDownloadBytes = 60 * 1024 * 1024

type DownloadRequest struct {
	Platform string
	Link     string
	Owner    string
}

// downloadPlatform reconoce los comandos con !, ? o sin prefijo.
func downloadPlatform(raw string) string {
	command := strings.TrimRight(normalize(raw), ".,!¡¿;:")
	switch command {
	case "!tiktok", "?tiktok", "tiktok", "!tt", "?tt":
		return "TikTok"
	case "!youtube", "?youtube", "youtube", "!yt", "?yt":
		return "YouTube"
	case "!instagram", "?instagram", "instagram", "!ig", "?ig":
		return "Instagram"
	default:
		return ""
	}
}

// requestedDownloadFormat busca el formato al final o después de otros argumentos.
func requestedDownloadFormat(fields []string) string {
	format := ""
	for _, field := range fields {
		switch strings.ToLower(strings.TrimSpace(field)) {
		case "mp3", "audio":
			format = "mp3"
		case "mp4", "video":
			format = "mp4"
		}
	}
	return format
}

// handleDownloadCommand reconoce los comandos públicos de descarga.
func (b *Bot) handleDownloadCommand(chat, sender types.JID, body string) bool {
	fields := strings.Fields(strings.TrimSpace(body))
	if len(fields) == 0 {
		return false
	}
	platform := downloadPlatform(fields[0])
	if platform == "" {
		return false
	}
	if len(fields) < 2 {
		b.send(chat, "📥 Uso: "+strings.ToLower(fields[0])+" https://enlace mp3|mp4")
		return true
	}
	link := strings.Trim(strings.TrimSpace(fields[1]), "<>\"'")
	if !validDownloadURL(platform, link) {
		b.send(chat, "❌ El enlace no parece ser de "+platform+". Enviá un enlace válido.")
		return true
	}
	format := requestedDownloadFormat(fields[2:])
	if format == "audio" {
		format = "mp3"
	}
	if format == "video" {
		format = "mp4"
	}
	if format != "" && format != "mp3" && format != "mp4" {
		b.send(chat, "Formato no válido. Elegí mp3 o mp4.")
		return true
	}
	if format == "" {
		b.mu.Lock()
		if b.downloadChoice == nil {
			b.downloadChoice = make(map[string]DownloadRequest)
		}
		// El comando inicial queda asociado al chat. La siguiente respuesta 1/2 elige formato.
		b.downloadChoice[downloadChoiceKey(chat, sender)] = DownloadRequest{Platform: platform, Link: link, Owner: sender.String()}
		b.mu.Unlock()
		b.send(chat, "📥 *¿En qué formato querés descargar de "+platform+"?*\n\n1️⃣ MP3 — solo audio\n2️⃣ MP4 — video\n\nRespondé 1, 2, MP3 o MP4. También podés indicar el formato al final del comando: !"+strings.ToLower(platform)+" ENLACE mp3 o mp4.")
		return true
	}
	b.startDownload(chat, platform, link, format)
	return true
}

// handleDownloadChoice consume 1/2 únicamente si hay una descarga pendiente en ese chat.
func downloadChoiceKey(chat, sender types.JID) string { return chat.String() + "|" + sender.String() }

func (b *Bot) handleDownloadChoice(chat, sender types.JID, body string) bool {
	choice := strings.ToLower(strings.TrimSpace(body))
	if choice != "1" && choice != "2" && choice != "mp3" && choice != "mp4" && choice != "audio" && choice != "video" {
		return false
	}
	b.mu.Lock()
	key := downloadChoiceKey(chat, sender)
	req, ok := b.downloadChoice[key]
	if ok {
		delete(b.downloadChoice, key)
	}
	b.mu.Unlock()
	if !ok {
		return false
	}
	format := "mp3"
	if choice == "2" || choice == "mp4" || choice == "video" {
		format = "mp4"
	}
	b.startDownload(chat, req.Platform, req.Link, format)
	return true
}

func (b *Bot) startDownload(chat types.JID, platform, link, format string) {
	label := "audio MP3"
	if format == "mp4" {
		label = "video MP4"
	}
	b.send(chat, "⏳ Descargando "+label+" de "+platform+"…")
	go b.downloadAndSend(chat, platform, link, format)
}

func validDownloadURL(platform, raw string) bool {
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "https" && u.Scheme != "http") || u.Hostname() == "" {
		return false
	}
	host := strings.ToLower(u.Hostname())
	switch platform {
	case "TikTok":
		return host == "tiktok.com" || strings.HasSuffix(host, ".tiktok.com")
	case "YouTube":
		return host == "youtu.be" || host == "youtube.com" || strings.HasSuffix(host, ".youtube.com") || host == "youtube-nocookie.com" || strings.HasSuffix(host, ".youtube-nocookie.com")
	case "Instagram":
		return host == "instagram.com" || strings.HasSuffix(host, ".instagram.com")
	}
	return false
}

// findYTDLP contempla tanto el ejecutable yt-dlp como instalaciones de pip
// accesibles únicamente mediante python -m yt_dlp en Termux.
func findYTDLP() (string, []string, error) {
	if path, err := exec.LookPath("yt-dlp"); err == nil {
		return path, nil, nil
	}
	for _, python := range []string{"python", "python3"} {
		if path, err := exec.LookPath(python); err == nil {
			check := exec.Command(path, "-m", "yt_dlp", "--version")
			if err := check.Run(); err == nil {
				return path, []string{"-m", "yt_dlp"}, nil
			}
		}
	}
	return "", nil, os.ErrNotExist
}

func (b *Bot) downloadAndSend(chat types.JID, platform, link, format string) {
	ytDLP, ytDLPArgs, err := findYTDLP()
	if err != nil {
		b.send(chat, "⚠️ No encuentro yt-dlp. Ejecutá: pkg install python ffmpeg -y && python -m pip install -U yt-dlp")
		return
	}
	if format == "mp3" {
		if _, err := exec.LookPath("ffmpeg"); err != nil {
			b.send(chat, "⚠️ Para MP3 falta ffmpeg. Ejecutá: pkg install ffmpeg -y")
			return
		}
	}
	dir, err := os.MkdirTemp("", "nexus-download-*")
	if err != nil {
		b.send(chat, "❌ No pude preparar la descarga.")
		return
	}
	defer os.RemoveAll(dir)
	output := filepath.Join(dir, "video.%(ext)s")
	args := []string{"--no-playlist", "--no-warnings", "--no-progress", "--no-part", "--force-overwrites", "--max-filesize", "60M", "--restrict-filenames", "-o", output}
	if format == "mp3" {
		// Descargamos la mejor pista de audio sin depender del postprocesador
		// de yt-dlp. Luego FFmpeg crea audio.mp3 de forma explícita.
		output = filepath.Join(dir, "audio-input.%(ext)s")
		args = []string{"--no-playlist", "--no-warnings", "--no-progress", "--no-part", "--force-overwrites", "--max-filesize", "60M", "--restrict-filenames", "-f", "bestaudio/best", "-o", output}
	} else {
		formatSelector := "best[ext=mp4]/best"
		if platform == "YouTube" {
			formatSelector = "best[height<=720][ext=mp4]/best[height<=720]/best[ext=mp4]/best"
		}
		args = append(args, "-f", formatSelector, "--merge-output-format", "mp4", "--recode-video", "mp4")
	}
	args = append(args, "--print", "after_move:filepath", link)
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()
	log.Printf("DESCARGA_INICIO | plataforma=%s | formato=%s | ejecutable=%s | destino=%s", platform, format, ytDLP, chat)
	cmd := exec.CommandContext(ctx, ytDLP, append(ytDLPArgs, args...)...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	if err := cmd.Run(); err != nil {
		log.Printf("DESCARGA_ERROR | plataforma=%s | formato=%s | error=%v | detalle=%s", platform, format, err, strings.TrimSpace(stderr.String()))
		if ctx.Err() == context.DeadlineExceeded {
			b.send(chat, "⌛ La descarga tardó demasiado. Probá nuevamente.")
		} else {
			detail := strings.TrimSpace(stderr.String())
			if len(detail) > 420 {
				detail = detail[:420] + "…"
			}
			msg := "❌ No pude descargar ese contenido. Puede ser privado, restringido o el servicio estar temporalmente caído."
			if detail != "" {
				msg += "\nDetalle técnico: " + detail
			}
			b.send(chat, msg)
		}
		return
	}
	path := strings.TrimSpace(stdout.String())
	if format == "mp3" {
		matches, _ := filepath.Glob(filepath.Join(dir, "audio-input.*"))
		if len(matches) == 0 {
			b.send(chat, "❌ Se descargó el enlace, pero no encontré la pista de audio.")
			return
		}
		converted := filepath.Join(dir, "audio.mp3")
		convertCtx, convertCancel := context.WithTimeout(context.Background(), 90*time.Second)
		convertCmd := exec.CommandContext(convertCtx, "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", matches[0], "-vn", "-codec:a", "libmp3lame", "-q:a", "0", converted)
		convertOutput, convertErr := convertCmd.CombinedOutput()
		convertCancel()
		if convertErr != nil {
			log.Printf("MP3_CONVERSION_ERROR | plataforma=%s | error=%v | detalle=%s", platform, convertErr, strings.TrimSpace(string(convertOutput)))
			b.send(chat, "❌ No pude convertir el audio a MP3. Actualizá FFmpeg con: pkg install ffmpeg -y")
			return
		}
		path = converted
	} else if path == "" {
		matches, _ := filepath.Glob(filepath.Join(dir, "video.*"))
		if len(matches) > 0 {
			path = matches[0]
		}
	}
	if path == "" || !strings.HasPrefix(filepath.Clean(path), filepath.Clean(dir)+string(os.PathSeparator)) {
		b.send(chat, "❌ El descargador no devolvió un archivo válido.")
		return
	}
	if format == "mp3" && strings.ToLower(filepath.Ext(path)) != ".mp3" {
		log.Printf("DESCARGA_FORMATO_INCORRECTO | plataforma=%s | solicitado=mp3 | archivo=%s", platform, filepath.Base(path))
		b.send(chat, "❌ No se generó un MP3 válido; no voy a enviarte otro formato como si fuera audio.")
		return
	}
	if format == "mp4" && strings.ToLower(filepath.Ext(path)) != ".mp4" {
		log.Printf("DESCARGA_FORMATO_INCORRECTO | plataforma=%s | solicitado=mp4 | archivo=%s", platform, filepath.Base(path))
		b.send(chat, "❌ yt-dlp no generó un MP4 válido. Actualizá yt-dlp y ffmpeg e intentá de nuevo.")
		return
	}
	info, err := os.Stat(path)
	if err != nil || info.Size() == 0 {
		b.send(chat, "❌ La descarga terminó pero no se encontró el archivo.")
		return
	}
	if info.Size() > maxDownloadBytes {
		b.send(chat, "⚠️ El archivo supera el límite de 60 MB para WhatsApp.")
		return
	}
	data, err := os.ReadFile(path)
	if err != nil {
		b.send(chat, "❌ No pude leer el archivo descargado.")
		return
	}
	if format == "mp3" {
		b.sendDownloadedAudio(chat, data, platform)
	} else {
		b.sendDownloadedVideo(chat, data, platform)
	}
}

func (b *Bot) sendDownloadedVideo(chat types.JID, data []byte, platform string) {
	if b.client == nil || !b.client.IsConnected() {
		b.send(chat, "❌ WhatsApp está desconectado; no pude enviar el video.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	upload, err := b.client.Upload(ctx, data, whatsmeow.MediaVideo)
	if err != nil {
		log.Printf("DESCARGA_SUBIDA_ERROR | plataforma=%s | formato=mp4 | error=%v", platform, err)
		b.send(chat, "❌ Descargué el video, pero WhatsApp no permitió subirlo.")
		return
	}
	video := &waProto.VideoMessage{URL: proto.String(upload.URL), Mimetype: proto.String("video/mp4"), FileSHA256: upload.FileSHA256, FileEncSHA256: upload.FileEncSHA256, MediaKey: upload.MediaKey, FileLength: proto.Uint64(uint64(len(data))), DirectPath: proto.String(upload.DirectPath), Caption: proto.String("📥 Video MP4 descargado de " + platform + "\nNEXUS TITAN")}
	resp, err := b.client.SendMessage(ctx, chat, &waProto.Message{VideoMessage: video})
	if err != nil {
		log.Printf("DESCARGA_ENVIO_ERROR | plataforma=%s | formato=mp4 | destino=%s | error=%v", platform, chat, err)
		b.send(chat, "❌ WhatsApp rechazó el envío del video.")
		return
	}
	log.Printf("DESCARGA_ENVIADA | plataforma=%s | formato=mp4 | destino=%s | id=%s | bytes=%d", platform, resp.Chat, resp.ID, len(data))
}

func (b *Bot) sendDownloadedAudio(chat types.JID, data []byte, platform string) {
	if b.client == nil || !b.client.IsConnected() {
		b.send(chat, "❌ WhatsApp está desconectado; no pude enviar el audio.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	upload, err := b.client.Upload(ctx, data, whatsmeow.MediaAudio)
	if err != nil {
		log.Printf("DESCARGA_SUBIDA_ERROR | plataforma=%s | formato=mp3 | error=%v", platform, err)
		b.send(chat, "❌ Descargué el MP3, pero WhatsApp no permitió subirlo.")
		return
	}
	audio := &waProto.AudioMessage{URL: proto.String(upload.URL), Mimetype: proto.String("audio/mpeg"), FileSHA256: upload.FileSHA256, FileEncSHA256: upload.FileEncSHA256, MediaKey: upload.MediaKey, FileLength: proto.Uint64(uint64(len(data))), DirectPath: proto.String(upload.DirectPath), PTT: proto.Bool(false)}
	resp, err := b.client.SendMessage(ctx, chat, &waProto.Message{AudioMessage: audio})
	if err != nil {
		log.Printf("DESCARGA_ENVIO_ERROR | plataforma=%s | formato=mp3 | destino=%s | error=%v", platform, chat, err)
		b.send(chat, "❌ WhatsApp rechazó el envío del MP3.")
		return
	}
	log.Printf("DESCARGA_ENVIADA | plataforma=%s | formato=mp3 | destino=%s | id=%s | bytes=%d", platform, resp.Chat, resp.ID, len(data))
}
