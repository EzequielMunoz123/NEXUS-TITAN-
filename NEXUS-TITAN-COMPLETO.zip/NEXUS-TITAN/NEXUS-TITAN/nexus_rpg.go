package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.mau.fi/whatsmeow/types"
)

const nexusRPGFile = "nexus-rpg.json"

type NexusRPGUser struct {
	Name    string    `json:"nombre"`
	Coins   int64     `json:"monedas"`
	XP      int64     `json:"xp"`
	DailyAt time.Time `json:"daily_at,omitempty"`
	WorkAt  time.Time `json:"work_at,omitempty"`
}

var nexusRPGMu sync.Mutex
var nexusRPGUsers map[string]NexusRPGUser

func loadNexusRPG() {
	nexusRPGMu.Lock()
	defer nexusRPGMu.Unlock()
	nexusRPGUsers = map[string]NexusRPGUser{}
	raw, err := os.ReadFile(nexusRPGFile)
	if err == nil {
		_ = json.Unmarshal(raw, &nexusRPGUsers)
	}
	if nexusRPGUsers == nil {
		nexusRPGUsers = map[string]NexusRPGUser{}
	}
}

func saveNexusRPGLocked() {
	raw, err := json.MarshalIndent(nexusRPGUsers, "", "  ")
	if err == nil {
		_ = os.WriteFile(nexusRPGFile, raw, 0600)
	}
}

func nexusRPGLevel(xp int64) int64 {
	level := int64(1)
	for xp >= level*level*100 {
		level++
	}
	return level
}

func (b *Bot) handleNexusRPG(to types.JID, number, body string) bool {
	fields := strings.Fields(strings.TrimSpace(body))
	if len(fields) == 0 {
		return false
	}
	cmd := strings.ToLower(fields[0])
	switch cmd {
	case "!perfil", ".perfil", "!fantasymy", ".fantasymy", "!balance", ".balance", "!monedas", ".monedas":
		nexusRPGMu.Lock()
		u := nexusRPGUsers[number]
		if u.Name == "" {
			u.Name = number
		}
		nexusRPGUsers[number] = u
		saveNexusRPGLocked()
		nexusRPGMu.Unlock()
		b.send(to, fmt.Sprintf("🧙 *PERFIL RPG · NEXUS TITAN*\n\n👤 %s\n🪙 Monedas: %d\n⭐ XP: %d\n🏅 Nivel: %d", u.Name, u.Coins, u.XP, nexusRPGLevel(u.XP)))
		return true
	case "!daily", ".daily", "!diario", ".diario":
		nexusRPGMu.Lock()
		u := nexusRPGUsers[number]
		if u.Name == "" {
			u.Name = number
		}
		if !u.DailyAt.IsZero() && time.Since(u.DailyAt) < 24*time.Hour {
			left := 24*time.Hour - time.Since(u.DailyAt)
			nexusRPGMu.Unlock()
			b.send(to, fmt.Sprintf("⏳ Ya reclamaste tu recompensa diaria. Volvé en %s.", left.Round(time.Minute)))
			return true
		}
		reward := int64(100 + rand.Intn(151))
		u.Coins += reward
		u.XP += 25
		u.DailyAt = time.Now()
		nexusRPGUsers[number] = u
		saveNexusRPGLocked()
		nexusRPGMu.Unlock()
		b.send(to, fmt.Sprintf("🎁 *RECOMPENSA DIARIA*\nRecibiste 🪙 %d monedas y ⭐ 25 XP.\nSaldo: %d monedas · Nivel %d", reward, u.Coins, nexusRPGLevel(u.XP)))
		return true
	case "!work", ".work", "!trabajar", ".trabajar":
		nexusRPGMu.Lock()
		u := nexusRPGUsers[number]
		if u.Name == "" {
			u.Name = number
		}
		if !u.WorkAt.IsZero() && time.Since(u.WorkAt) < time.Hour {
			left := time.Hour - time.Since(u.WorkAt)
			nexusRPGMu.Unlock()
			b.send(to, fmt.Sprintf("🕒 Ya trabajaste recientemente. Descansá %s.", left.Round(time.Minute)))
			return true
		}
		reward := int64(20 + rand.Intn(61))
		u.Coins += reward
		u.XP += 10
		u.WorkAt = time.Now()
		nexusRPGUsers[number] = u
		saveNexusRPGLocked()
		nexusRPGMu.Unlock()
		b.send(to, fmt.Sprintf("🛠️ Terminaste un trabajo y ganaste 🪙 %d monedas + ⭐ 10 XP.\nSaldo: %d monedas.", reward, u.Coins))
		return true
	case "!fyentregar", ".fyentregar":
		if len(fields) != 3 {
			b.send(to, "Uso: !fyentregar NUMERO CANTIDAD\nEjemplo: !fyentregar 549XXXXXXXXX 50")
			return true
		}
		target := clean(fields[1])
		amount, err := strconv.ParseInt(fields[2], 10, 64)
		if target == "" || target == number || err != nil || amount <= 0 {
			b.send(to, "⚠️ Número o cantidad inválida. La transferencia debe ser positiva y no podés enviarte monedas a vos mismo.")
			return true
		}
		nexusRPGMu.Lock()
		fromUser := nexusRPGUsers[number]
		toUser := nexusRPGUsers[target]
		if fromUser.Coins < amount {
			nexusRPGMu.Unlock()
			b.send(to, "🪙 No tenés suficientes monedas para esa transferencia.")
			return true
		}
		if toUser.Name == "" {
			toUser.Name = target
		}
		if fromUser.Name == "" {
			fromUser.Name = number
		}
		fromUser.Coins -= amount
		toUser.Coins += amount
		nexusRPGUsers[number] = fromUser
		nexusRPGUsers[target] = toUser
		saveNexusRPGLocked()
		nexusRPGMu.Unlock()
		b.send(to, fmt.Sprintf("💸 Transferiste %d monedas a %s. Tu saldo es %d.", amount, target, fromUser.Coins))
		return true
	case "!fytendencia", ".fytendencia":
		nexusRPGMu.Lock()
		u := nexusRPGUsers[number]
		nexusRPGMu.Unlock()
		level := nexusRPGLevel(u.XP)
		next := level * level * 100
		remaining := next - u.XP
		if remaining < 0 {
			remaining = 0
		}
		b.send(to, fmt.Sprintf("📈 *PROGRESO RPG*\nNivel actual: %d\nXP: %d\nPróximo nivel: %d XP restantes", level, u.XP, remaining))
		return true
	case "!top", ".top", "!leaderboard", ".leaderboard", "!fyranking", ".fyranking":
		nexusRPGMu.Lock()
		type entry struct {
			Number string
			User   NexusRPGUser
		}
		rows := make([]entry, 0, len(nexusRPGUsers))
		for n, u := range nexusRPGUsers {
			rows = append(rows, entry{n, u})
		}
		nexusRPGMu.Unlock()
		sort.Slice(rows, func(i, j int) bool {
			if rows[i].User.XP == rows[j].User.XP {
				return rows[i].User.Coins > rows[j].User.Coins
			}
			return rows[i].User.XP > rows[j].User.XP
		})
		if len(rows) > 10 {
			rows = rows[:10]
		}
		var out strings.Builder
		out.WriteString("🏆 *TOP RPG · NEXUS TITAN*\n\n")
		for i, row := range rows {
			name := row.User.Name
			if name == "" {
				name = row.Number
			}
			fmt.Fprintf(&out, "%d. %s — Nivel %d · %d XP · 🪙 %d\n", i+1, name, nexusRPGLevel(row.User.XP), row.User.XP, row.User.Coins)
		}
		if len(rows) == 0 {
			out.WriteString("Todavía no hay jugadores RPG.")
		}
		b.send(to, out.String())
		return true
	}
	return false
}
