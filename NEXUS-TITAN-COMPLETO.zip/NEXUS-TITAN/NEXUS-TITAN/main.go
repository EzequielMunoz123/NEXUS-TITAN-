package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	mathrand "math/rand"
	"os"
	"os/signal"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/mdp/qrterminal/v3"
	"go.mau.fi/whatsmeow"
	waCommon "go.mau.fi/whatsmeow/proto/waCommon"
	waProto "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protoreflect"
	_ "modernc.org/sqlite"
)

const (
	dbFile     = "whatsapp-session.db"
	stateFile  = "estado-partido.json"
	maxRoster  = 30
	maxPlayers = 10
)

type Player struct {
	Number string `json:"numero"`
	Name   string `json:"nombre"`
}
type Answer struct {
	Number          string `json:"numero"`
	Name            string `json:"nombre"`
	Status          string `json:"estado"`
	PaymentMethod   string `json:"metodo_pago,omitempty"`
	ReceiptReceived bool   `json:"comprobante_recibido,omitempty"`
	Paid            bool   `json:"pago_confirmado,omitempty"`
	PaymentRejected bool   `json:"pago_rechazado,omitempty"`
}
type Match struct {
	Active                       bool `json:"activo"`
	Name, Place, Day, Hour, Cost string
	CreatedAt                    time.Time         `json:"creado_en,omitempty"`
	ExpiresAt                    time.Time         `json:"vence_en,omitempty"`
	KickoffAt                    time.Time         `json:"inicio_partido,omitempty"`
	ClosedAt                     time.Time         `json:"lista_cerrada_en,omitempty"`
	CloseReason                  string            `json:"motivo_cierre,omitempty"`
	Invited                      []string          `json:"convocados"`
	ListOnlyNames                []string          `json:"lista_sin_contacto,omitempty"`
	Answers                      map[string]Answer `json:"respuestas"`
}
type State struct {
	Match    Match    `json:"partido"`
	Players  []Player `json:"jugadores"`
	ListOnly []Player `json:"lista_aparte,omitempty"`
	Blocked  []string `json:"numeros_bloqueados,omitempty"`
	ChatMode bool     `json:"modo_charla,omitempty"`
	JokeMode bool     `json:"modo_broma,omitempty"`
	AutoAI   bool     `json:"ia_automatica,omitempty"`
}
type Bot struct {
	mu             sync.Mutex
	client         *whatsmeow.Client
	state          State
	flow           map[string]string
	temp           map[string]map[string]string
	seen           map[string]time.Time
	history        map[string][]StoredMessage
	historyTarget  map[string]string              // último número consultado por cada administrador
	downloadChoice map[string]DownloadRequest     // elección pendiente de formato por chat y remitente
	audioForward   map[string]PendingAudioForward // audio citado pendiente de destinatario
	pendingSticker map[string]PendingSticker
	aiContext      map[string][]chatMessage
	ownNumber      string
	presenceMu     sync.Mutex
	presenceGen    uint64
	presenceTimer  *time.Timer
}

// Al recibir un mensaje, muestra el bot en línea durante 20 segundos.
// La conexión WebSocket permanece activa para no perder mensajes entrantes.
func (b *Bot) showOnlineFor20Seconds() {
	if b.client == nil {
		return
	}
	if err := b.client.SendPresence(context.Background(), types.PresenceAvailable); err != nil {
		log.Printf("AVISO presencia en línea: %v", err)
		return
	}
	b.presenceMu.Lock()
	b.presenceGen++
	gen := b.presenceGen
	if b.presenceTimer != nil {
		b.presenceTimer.Stop()
	}
	b.presenceTimer = time.AfterFunc(20*time.Second, func() {
		b.presenceMu.Lock()
		defer b.presenceMu.Unlock()
		if gen != b.presenceGen || b.client == nil {
			return
		}
		if err := b.client.SendPresence(context.Background(), types.PresenceUnavailable); err != nil {
			log.Printf("AVISO presencia desconectada: %v", err)
		}
		b.presenceTimer = nil
	})
	b.presenceMu.Unlock()
}

var admins = []Player{{"5493734419761", "Ezequiel Muñoz"}, {"5493734468061", "Gonza Acosta"}}
var initialPlayers = []Player{
	{"5493734419761", "Eze Muñoz"}, {"5493734468061", "Gonza Acosta"},
	{"5493734514813", "Facu Fernández"}, {"5493734511829", "Matías Pintos"}, {"5493734521158", "Maisi Flores"},
	{"5493734526464", "Jonas"}, {"5493734443703", "Mancilla"}, {"5493734486765", "Maña"},
	{"5493734536490", "Rodri Alegre"}, {"5493734447213", "Fer Garcia"}, {"5493734526212", "Tiago Wave Roja"},
	{"5493734417327", "Dani Rep"}, {"5493734533942", "Benja Castillo"},
}
var digits = regexp.MustCompile(`\D`)

func clean(s string) string {
	return digits.ReplaceAllString(strings.Split(strings.Split(s, "@")[0], ":")[0], "")
}
func normalize(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	r := strings.NewReplacer("á", "a", "é", "e", "í", "i", "ó", "o", "ú", "u")
	return r.Replace(s)
}
func answer(s string) string {
	// Acepta respuestas naturales breves, no solamente un "SI" aislado.
	// Ejemplos: "Te pongo un Si", "Si pue compa", "voy de una".
	normalized := normalize(strings.ToLower(strings.TrimSpace(s)))
	fields := strings.FieldsFunc(normalized, func(r rune) bool {
		return !(r >= 'a' && r <= 'z') && !(r >= '0' && r <= '9')
	})
	if len(fields) == 0 {
		return ""
	}
	joined := " " + strings.Join(fields, " ") + " "
	// No tomar frases de duda como "no sé si puedo" por una confirmación.
	if strings.HasPrefix(joined, " no se ") || strings.Contains(joined, " no se si ") {
		return ""
	}
	for _, phrase := range []string{" no puedo ", " no voy ", " no llego ", " no juego ", " no asisto ", " no participo ", " no me anoto ", " esta vez no ", " hoy no ", " paso ", " no gracias "} {
		if strings.Contains(joined, phrase) {
			return "NO"
		}
	}
	if fields[0] == "no" || (len(fields) == 1 && fields[0] == "n") {
		return "NO"
	}
	for _, token := range fields {
		switch token {
		case "si", "s", "confirmo", "voy", "ok", "dale", "estoy", "confirmado", "anoto":
			return "SI"
		}
	}
	if strings.Contains(joined, " de una ") || strings.Contains(joined, " cuenta conmigo ") || strings.Contains(joined, " me sumo ") || strings.Contains(joined, " me anoto ") || strings.Contains(joined, " voy a jugar ") {
		return "SI"
	}
	return ""
}
func jid(number string) types.JID { return types.NewJID(clean(number), types.DefaultUserServer) }
func (b *Bot) save() {
	data, e := json.MarshalIndent(b.state, "", "  ")
	if e == nil {
		_ = os.WriteFile(stateFile, data, 0600)
	}
}

// handleRandomAudio detecta notas de voz y archivos de audio, incluidos documentos audio/*.
func (b *Bot) reactToMessage(m *events.Message, emoji string, label string) {
	if m == nil || b.client == nil || m.Info.ID == "" {
		return
	}
	key := &waCommon.MessageKey{RemoteJID: proto.String(m.Info.Chat.String()), FromMe: proto.Bool(m.Info.IsFromMe), ID: proto.String(string(m.Info.ID))}
	if m.Info.IsGroup && !m.Info.Sender.IsEmpty() {
		key.Participant = proto.String(m.Info.Sender.String())
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	if _, err := b.client.SendMessage(ctx, m.Info.Chat, &waProto.Message{ReactionMessage: &waProto.ReactionMessage{Key: key, Text: proto.String(emoji)}}); err != nil {
		log.Printf("ERROR reaccion %s | chat=%s | id=%s | err=%v", label, m.Info.Chat, m.Info.ID, err)
		return
	}
	log.Printf("REACCION_AUTO | tipo=%s | chat=%s | id=%s | emoji=%s", label, m.Info.Chat, m.Info.ID, emoji)
}

// handleRandomAudio reacciona a los audios; nunca responde con texto ni con un emoji suelto.
func (b *Bot) handleRandomAudio(m *events.Message, message *waProto.Message) bool {
	if m == nil || message == nil {
		return false
	}
	message = unwrapIncomingMessage(message)
	tipo := ""
	if audio := message.GetAudioMessage(); audio != nil {
		tipo = "audio"
		if audio.GetPTT() {
			tipo = "nota_de_voz"
		}
	} else if doc := message.GetDocumentMessage(); doc != nil && strings.HasPrefix(strings.ToLower(doc.GetMimetype()), "audio/") {
		tipo = "documento_audio"
	} else {
		return false
	}
	emojis := []string{"😂", "🤣", "💀", "👀", "🔥", "😭", "😎", "❤️", "🤔", "👏", "🎧", "👍", "🥶", "😅"}
	b.reactToMessage(m, emojis[mathrand.Intn(len(emojis))], tipo)
	return true
}

func isBotCommand(body string) bool {
	body = strings.TrimSpace(body)
	return strings.HasPrefix(body, "!") || strings.HasPrefix(body, "?") || strings.HasPrefix(body, "/")
}

func (b *Bot) reactToPhoto(m *events.Message, message *waProto.Message) {
	if message == nil || message.GetImageMessage() == nil {
		return
	}
	emojis := []string{"📸", "🔥", "😍", "👏", "❤️", "👀", "👍"}
	b.reactToMessage(m, emojis[mathrand.Intn(len(emojis))], "foto")
}

func (b *Bot) send(to types.JID, text string) bool {
	if strings.TrimSpace(text) == "" {
		log.Printf("ERROR envio: mensaje vacío")
		return false
	}
	if to.IsEmpty() {
		log.Printf("ERROR envio: destino JID vacío")
		return false
	}
	if b.client == nil {
		log.Printf("ERROR envio a %s: cliente WhatsApp no inicializado", to)
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	resp, err := b.client.SendMessage(ctx, to, &waProto.Message{Conversation: proto.String(text)})
	if err != nil {
		log.Printf("ERROR envio a %s: %v", to, err)
		return false
	}
	log.Printf("ENVIADO | destino_solicitado=%s | destino_whatsapp=%s | remitente=%s | id=%s | bytes=%d | demora_envio=%s | estado=esperando_recibo", to, resp.Chat, resp.Sender, resp.ID, len(text), resp.DebugTimings.Send)
	return true
}

// sendToPhone verifica el número y entrega a whatsmeow el JID telefónico.
// whatsmeow usa el mapeo PN<->LID guardado por IsOnWhatsApp para convertirlo
// al LID correcto y adjuntar el PN del destinatario al envío.
func (b *Bot) sendToPhone(number, text string) bool {
	n := clean(number)
	if len(n) < 10 {
		log.Printf("ERROR destinatario: número internacional inválido %q", number)
		return false
	}
	if b.client == nil || !b.client.IsConnected() {
		log.Printf("ERROR destinatario %s: cliente WhatsApp desconectado", n)
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	results, err := b.client.IsOnWhatsApp(ctx, []string{"+" + n})
	if err != nil {
		log.Printf("ERROR verificación WhatsApp %s: %v", n, err)
		return false
	}
	if len(results) == 0 || results[0].JID.IsEmpty() {
		log.Printf("ERROR destinatario %s: WhatsApp no devolvió un JID registrado", n)
		return false
	}
	resolved := results[0].JID
	phoneJID := results[0].PhoneNumber
	log.Printf("DESTINATARIO_VERIFICADO | numero=%s | jid_lid=%s | jid_telefono=%s", n, resolved, phoneJID)
	// Preferir el JID telefónico: SendMessage usa el mapeo PN<->LID de
	// whatsmeow y construye la dirección final del destinatario.
	if !phoneJID.IsEmpty() {
		if phoneJID.Server == types.LegacyUserServer {
			phoneJID.Server = types.DefaultUserServer
		}
		if phoneJID.Server == types.DefaultUserServer {
			return b.send(phoneJID, text)
		}
		log.Printf("AVISO destinatario %s: JID telefónico inesperado %s; se usará el LID verificado", n, phoneJID)
	}
	return b.send(resolved, text)
}

// sendImageToPhone envía una imagen ya subida a WhatsApp, con su descripción.
// La carga se realiza una sola vez y el mismo contenido cifrado se reutiliza
// para cada destinatario de !mensaje.
func (b *Bot) sendImageToPhone(number string, image *waProto.ImageMessage) bool {
	n := clean(number)
	if len(n) < 10 || b.client == nil || !b.client.IsConnected() {
		log.Printf("ERROR imagen destinatario inválido/desconectado: %s", n)
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	results, err := b.client.IsOnWhatsApp(ctx, []string{"+" + n})
	if err != nil || len(results) == 0 || results[0].JID.IsEmpty() {
		log.Printf("ERROR verificación WhatsApp para imagen %s: %v", n, err)
		return false
	}
	dest := results[0].PhoneNumber
	if dest.IsEmpty() {
		dest = results[0].JID
	}
	if dest.Server == types.LegacyUserServer {
		dest.Server = types.DefaultUserServer
	}
	msg := &waProto.Message{ImageMessage: proto.Clone(image).(*waProto.ImageMessage)}
	resp, err := b.client.SendMessage(ctx, dest, msg)
	if err != nil {
		log.Printf("ERROR envío imagen a %s: %v", n, err)
		return false
	}
	log.Printf("ENVIADO_IMAGEN | numero=%s | destino=%s | remitente=%s | id=%s | bytes=%d | estado=esperando_recibo", n, resp.Chat, resp.Sender, resp.ID, image.GetFileLength())
	return true
}

// handleAdminImageFlow procesa una foto recibida mientras el administrador
// está completando el flujo !mensaje. Esto tiene prioridad sobre comprobantes.
func (b *Bot) handleAdminImageFlow(from types.JID, number string, incoming *waProto.ImageMessage, msgID string) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	number = clean(number)
	if b.flow[number] != "mensaje_texto" {
		return false
	}
	caption := strings.TrimSpace(incoming.GetCaption())
	if caption == "" {
		b.send(from, "La foto no tiene texto. Volvé a enviarla agregando la descripción en el campo de comentario de la imagen.")
		return true
	}
	target := normalize(b.temp[number]["destino"])
	recipients := []string{}
	seen := map[string]bool{}
	add := func(n string) {
		n = clean(n)
		if n != "" && !seen[n] && !b.isBlocked(n) {
			seen[n] = true
			recipients = append(recipients, n)
		}
	}
	switch target {
	case "todos":
		for _, player := range append(append([]Player{}, b.state.Players...), b.state.ListOnly...) {
			add(player.Number)
		}
	case "pendientes", "confirmados":
		if !b.state.Match.Active && b.state.Match.Name == "" {
			b.send(from, "No hay un partido cargado para identificar pendientes o confirmados.")
			return true
		}
		for _, n := range b.state.Match.Invited {
			a, answered := b.state.Match.Answers[clean(n)]
			if target == "pendientes" && !answered {
				add(n)
			}
			if target == "confirmados" && answered && a.Status == "SI" {
				add(n)
			}
		}
	default:
		add(b.temp[number]["destino"])
	}
	if len(recipients) == 0 {
		b.send(from, "No encontré destinatarios para ese envío. El flujo sigue activo; revisá el destino o cancelá con !cancelar.")
		return true
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	data, err := b.client.Download(ctx, incoming)
	if err != nil {
		cancel()
		log.Printf("ERROR descargando foto de !mensaje: %v", err)
		b.send(from, "No pude descargar la foto de WhatsApp. Sigue pendiente el envío; volvé a adjuntarla.")
		return true
	}
	media, err := b.client.Upload(ctx, data, whatsmeow.MediaImage)
	cancel()
	if err != nil {
		log.Printf("ERROR subiendo foto de !mensaje: %v", err)
		b.send(from, "No pude preparar la foto para enviarla. Sigue pendiente el envío; intentá nuevamente.")
		return true
	}
	mime := incoming.GetMimetype()
	if mime == "" {
		mime = "image/jpeg"
	}
	caption = "📢 MENSAJE DE ADMINISTRACIÓN\n" + caption
	image := &waProto.ImageMessage{
		URL: &media.URL, DirectPath: &media.DirectPath, MediaKey: media.MediaKey,
		FileEncSHA256: media.FileEncSHA256, FileSHA256: media.FileSHA256,
		FileLength: &media.FileLength, Mimetype: proto.String(mime), Caption: proto.String(caption),
	}
	sent, failed := 0, 0
	for _, recipient := range recipients {
		if b.sendImageToPhone(recipient, image) {
			sent++
		} else {
			failed++
		}
	}
	if failed == 0 {
		b.send(from, fmt.Sprintf("📨 Foto con descripción enviada a %d destinatario(s). WhatsApp confirmará la entrega mediante sus recibos.", sent))
		delete(b.flow, number)
		delete(b.temp, number)
	} else {
		b.send(from, fmt.Sprintf("⚠️ Foto enviada a %d destinatario(s); %d fallaron. Revisá los registros de Termux.", sent, failed))
		delete(b.flow, number)
		delete(b.temp, number)
	}
	return true
}

func (b *Bot) find(number string) (Player, bool) {
	n := clean(number)
	for _, p := range b.state.Players {
		if clean(p.Number) == n || (len(n) >= 10 && len(clean(p.Number)) >= 10 && strings.HasSuffix(n, clean(p.Number)[len(clean(p.Number))-10:])) {
			return p, true
		}
	}
	return Player{}, false
}
func (b *Bot) findListOnly(number string) (Player, bool) {
	n := clean(number)
	for _, p := range b.state.ListOnly {
		if clean(p.Number) == n {
			return p, true
		}
	}
	return Player{}, false
}
func (b *Bot) findAny(number string) (Player, bool) {
	if p, ok := b.find(number); ok {
		return p, true
	}
	return b.findListOnly(number)
}

func appendAdminOnce(list []Player, number string) []Player {
	number = clean(number)
	for _, a := range list {
		if clean(a.Number) == number {
			return list
		}
	}
	return append(list, Player{Number: number, Name: "Dueño del bot"})
}

func isAdmin(n string) bool {
	n = clean(n)
	for _, a := range admins {
		if clean(a.Number) == n {
			return true
		}
	}
	return false
}
func adminDisplay(number string) string {
	for _, a := range admins {
		if clean(a.Number) == clean(number) {
			return a.Name
		}
	}
	return "Administrador"
}

func (b *Bot) notifyAdmins(msg string) {
	for _, a := range admins {
		b.sendToPhone(a.Number, msg)
	}
}

// notifyOtherAdmin evita enviar al administrador que ejecutó la acción.
func (b *Bot) notifyOtherAdmin(actorNumber, msg string) {
	actorNumber = clean(actorNumber)
	for _, a := range admins {
		if clean(a.Number) != actorNumber {
			b.sendToPhone(a.Number, msg)
		}
	}
}

func (b *Bot) confirmTransferPayment(number string) (string, bool) {
	number = clean(number)
	if number == "" {
		return "Número inválido. Usá el número internacional, sin + ni espacios.", false
	}
	p, ok := b.findAny(number)
	if !ok {
		return "No encuentro ese teléfono en el plantel o la lista del partido: " + number, false
	}
	key := clean(p.Number)
	a, ok := b.state.Match.Answers[key]
	if !ok || a.Status != "SI" {
		return p.Name + " todavía no confirmó asistencia en este partido.", false
	}
	if a.PaymentMethod != "TRANSFERENCIA" {
		return p.Name + " no tiene TRANSFERENCIA registrada como método de pago.", false
	}
	if !a.ReceiptReceived {
		return "Todavía no recibí un comprobante desde el WhatsApp de " + p.Name + " (" + key + "). No puedo marcarlo pagado.", false
	}
	// La aprobación queda persistida antes del aviso. Si el aviso falla, repetir
	// !confirmarpago reintenta el envío sin duplicar ni perder la aprobación.
	if !a.Paid {
		a.Paid = true
		a.PaymentRejected = false
		b.state.Match.Answers[key] = a
		b.save()
	}
	msg := "✅ *PAGO APROBADO*\nTu pago por transferencia para el partido " + b.state.Match.Name + " fue revisado y aprobado por la administración. ¡Gracias!"
	if !b.sendToPhone(p.Number, msg) {
		return "⚠️ El pago de " + p.Name + " quedó aprobado, pero WhatsApp no confirmó el envío del aviso. Revisá la conexión y repetí !confirmarpago " + key + " para reintentar.", true
	}
	return "✅ Pago por transferencia aprobado para " + p.Name + " (" + key + "). WhatsApp aceptó el aviso para su chat.", true
}

// rejectTransferPayment registra el rechazo administrativo y avisa al jugador.
// La decisión la toma una persona: el bot no valida movimientos bancarios.
func (b *Bot) rejectTransferPayment(number string) (string, bool) {
	number = clean(number)
	if number == "" {
		return "Número inválido. Usá el número internacional, sin + ni espacios.", false
	}
	p, ok := b.findAny(number)
	if !ok {
		return "No encuentro ese teléfono en el plantel o la lista del partido: " + number, false
	}
	key := clean(p.Number)
	a, ok := b.state.Match.Answers[key]
	if !ok || a.Status != "SI" {
		return p.Name + " todavía no confirmó asistencia en este partido.", false
	}
	if a.PaymentMethod != "TRANSFERENCIA" {
		return p.Name + " no tiene TRANSFERENCIA registrada como método de pago.", false
	}
	if a.Paid {
		return "El pago de " + p.Name + " ya está aprobado. No se puede rechazar sin revertir primero la aprobación.", false
	}
	if !a.PaymentRejected {
		a.PaymentRejected = true
		b.state.Match.Answers[key] = a
		b.save()
	}
	msg := "❌ *PAGO RECHAZADO*\nLa administración revisó tu pago por transferencia del partido " + b.state.Match.Name + " y no pudo confirmar que el dinero haya ingresado. Si ya transferiste, enviá el comprobante correcto o comunicate con Eze Muñoz/Gonza Acosta para revisarlo."
	if !b.sendToPhone(p.Number, msg) {
		return "⚠️ El pago de " + p.Name + " quedó marcado como rechazado, pero WhatsApp no confirmó el envío del aviso. Revisá la conexión y repetí !rechazarpago " + key + " para reintentar.", true
	}
	return "❌ Pago de " + p.Name + " rechazado. WhatsApp aceptó el aviso para su chat.", true
}
func (b *Bot) count(status string) int {
	n := 0
	for _, a := range b.state.Match.Answers {
		if a.Status == status {
			n++
		}
	}
	return n
}

// confirmedCount incluye respuestas SI y nombres agregados manualmente sin teléfono.
func (b *Bot) confirmedCount() int {
	seen := map[string]bool{}
	for _, a := range b.state.Match.Answers {
		if a.Status == "SI" {
			seen[normalize(a.Name)] = true
		}
	}
	for _, name := range b.state.Match.ListOnlyNames {
		if strings.TrimSpace(name) != "" {
			seen[normalize(name)] = true
		}
	}
	return len(seen)
}
func (b *Bot) listText() string {
	m := b.state.Match
	var yes, no, pending []string
	for _, n := range m.Invited {
		a, ok := m.Answers[n]
		if !ok {
			if p, found := b.findAny(n); found {
				pending = append(pending, p.Name)
			}
			continue
		}
		if a.Status == "SI" {
			yes = append(yes, a.Name+paymentLabel(a))
		} else if a.Status == "NO" {
			no = append(no, a.Name)
		}
	}
	for _, name := range m.ListOnlyNames {
		yes = append(yes, name+" (sin número)")
	}
	return fmt.Sprintf("⚽ %s\n📍 %s | 📅 %s | ⏰ %s | 💰 %s\n\n✅ CONFIRMADOS (%d/%d):\n%s\n\n❌ NO DISPONIBLES (%d):\n%s\n\n⏳ PENDIENTES (%d):\n%s", m.Name, m.Place, m.Day, m.Hour, m.Cost, b.confirmedCount(), maxPlayers, orEmpty(yes), len(no), orEmpty(no), len(pending), orEmpty(pending))
}
func (b *Bot) progressText() string {
	m := b.state.Match
	yes, no, pending := b.confirmedCount(), b.count("NO"), 0
	for _, n := range m.Invited {
		if _, ok := m.Answers[clean(n)]; !ok {
			pending++
		}
	}
	remaining := maxPlayers - yes
	if remaining < 0 {
		remaining = 0
	}
	return fmt.Sprintf("📊 ACTUALIZACIÓN DEL PARTIDO\n⚽ %s\n✅ Confirmados: %d/%d\n❌ No pueden: %d\n⏳ Faltan responder: %d\n🟢 Cupos disponibles: %d", m.Name, yes, maxPlayers, no, pending, remaining)
}

func paymentLabel(a Answer) string {
	if a.PaymentMethod == "EFECTIVO" {
		return " — efectivo"
	}
	if a.PaymentMethod == "TRANSFERENCIA" {
		if a.Paid {
			return " — transferencia (PAGADO ✓)"
		}
		if a.PaymentRejected {
			return " — transferencia (RECHAZADO ✗)"
		}
		if a.ReceiptReceived {
			return " — transferencia (comprobante recibido, falta aprobación)"
		}
		return " — transferencia (falta comprobante)"
	}
	return " — falta método de pago"
}
func orEmpty(v []string) string {
	if len(v) == 0 {
		return "Ninguno"
	}
	return strings.Join(v, "\n")
}

// Argentina local time is used for match dates and automatic list closing.
func argentinaLocation() *time.Location {
	loc, err := time.LoadLocation("America/Argentina/Buenos_Aires")
	if err != nil {
		return time.Local
	}
	return loc
}

func parseMatchDate(day, hour string, now time.Time) (time.Time, error) {
	loc := argentinaLocation()
	now = now.In(loc)
	d := strings.TrimSpace(normalize(day))
	var date time.Time
	parsed := false
	for _, layout := range []string{"02/01/2006", "2/1/2006", "2006-01-02", "02-01-2006", "2-1-2006", "02/01", "2/1", "02-01", "2-1"} {
		if t, err := time.ParseInLocation(layout, d, loc); err == nil {
			date = t
			if !strings.Contains(layout, "2006") {
				date = time.Date(now.Year(), t.Month(), t.Day(), 0, 0, 0, 0, loc)
				if date.Before(now) {
					date = date.AddDate(1, 0, 0)
				}
			}
			parsed = true
			break
		}
	}
	if !parsed {
		switch d {
		case "hoy":
			date = time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, loc)
			parsed = true
		case "manana":
			date = time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, loc)
			parsed = true
		default:
			weekdays := map[string]time.Weekday{"domingo": time.Sunday, "lunes": time.Monday, "martes": time.Tuesday, "miercoles": time.Wednesday, "jueves": time.Thursday, "viernes": time.Friday, "sabado": time.Saturday}
			if wd, ok := weekdays[d]; ok {
				delta := (int(wd) - int(now.Weekday()) + 7) % 7
				if delta == 0 {
					delta = 7
				}
				date = time.Date(now.Year(), now.Month(), now.Day()+delta, 0, 0, 0, 0, loc)
				parsed = true
			}
		}
	}
	if !parsed {
		return time.Time{}, fmt.Errorf("fecha no reconocida")
	}
	h := strings.ToLower(strings.TrimSpace(hour))
	h = strings.TrimSuffix(h, " hs")
	h = strings.TrimSuffix(h, "hs")
	h = strings.ReplaceAll(h, ".", ":")
	var clock time.Time
	var err error
	for _, layout := range []string{"15:04", "15:04:05", "15"} {
		clock, err = time.Parse(layout, h)
		if err == nil {
			break
		}
	}
	if err != nil {
		return time.Time{}, fmt.Errorf("hora no reconocida")
	}
	return time.Date(date.Year(), date.Month(), date.Day(), clock.Hour(), clock.Minute(), 0, 0, loc), nil
}

func (b *Bot) finalNames() []string {
	m := b.state.Match
	var names []string
	seen := map[string]bool{}
	for _, n := range m.Invited {
		if a, ok := m.Answers[clean(n)]; ok && a.Status == "SI" {
			k := normalize(a.Name)
			if !seen[k] {
				names = append(names, a.Name)
				seen[k] = true
			}
		}
	}
	for _, name := range m.ListOnlyNames {
		k := normalize(name)
		if strings.TrimSpace(name) != "" && !seen[k] {
			names = append(names, name)
			seen[k] = true
		}
	}
	return names
}

// closeMatchLocked is called only while b.mu is held. It is idempotent.
func (b *Bot) closeMatchLocked(reason string) {
	m := &b.state.Match
	if !m.Active {
		return
	}
	m.Active = false
	m.ClosedAt = time.Now().In(argentinaLocation())
	m.CloseReason = reason
	b.save()
	names := b.finalNames()
	list := "Ninguno"
	if len(names) > 0 {
		list = strings.Join(names, "\n")
	}
	final := fmt.Sprintf("⚽ LISTA CERRADA — %s\n📍 %s\n📅 %s | ⏰ %s\n💰 Importe por jugador: %s\n\n✅ JUGADORES QUE QUEDARON:\n%s\n\n¡Los esperamos! Recuerden llevar el importe de cada jugador.", m.Name, m.Place, m.Day, m.Hour, m.Cost, list)
	for _, n := range m.Invited {
		if a, ok := m.Answers[clean(n)]; ok && a.Status == "SI" && !b.isBlocked(n) {
			b.sendToPhone(n, final)
		}
	}
	b.notifyAdmins("🔒 Lista cerrada (" + reason + ")\n" + final)
	log.Printf("LISTA CERRADA | %s | motivo=%s | confirmados=%d", m.Name, reason, b.confirmedCount())
}

// isBlocked ignora siempre os administradores y compara números normalizados.
func (b *Bot) isBlocked(number string) bool {
	n := clean(number)
	if n == "" || isAdmin(n) {
		return false
	}
	for _, blocked := range b.state.Blocked {
		if clean(blocked) == n {
			return true
		}
	}
	return false
}

func (b *Bot) handle(from types.JID, number string, body, msgID string) {
	b.mu.Lock()
	defer b.mu.Unlock()
	number = clean(number)
	if b.isBlocked(number) {
		log.Printf("IGNORADO | número bloqueado | %s", number)
		return
	}
	if b.flow == nil {
		b.flow = map[string]string{}
	}
	if b.temp == nil {
		b.temp = map[string]map[string]string{}
	}
	if b.seen == nil {
		b.seen = map[string]time.Time{}
	}
	if b.state.Match.Answers == nil {
		b.state.Match.Answers = map[string]Answer{}
	}
	if msgID != "" {
		if t, ok := b.seen[msgID]; ok && time.Since(t) < 24*time.Hour {
			return
		}
		b.seen[msgID] = time.Now()
	}
	p, registered := b.findAny(number)
	admin := isAdmin(number)
	if b.state.Match.Active {
		now := time.Now()
		if !b.state.Match.KickoffAt.IsZero() && !now.Before(b.state.Match.KickoffAt.Add(-20*time.Minute)) {
			b.closeMatchLocked("faltan 20 minutos para el partido")
		} else if !b.state.Match.ExpiresAt.IsZero() && !now.Before(b.state.Match.ExpiresAt) {
			b.closeMatchLocked("venció el plazo máximo de 5 horas")
		}
	}
	text := strings.TrimSpace(body)
	if text == "" {
		return
	}
	log.Printf("ENTRANTE | %s | %s", number, strings.ReplaceAll(text, "\n", " "))
	if response, ok := menuResponse(text, admin); ok {
		log.Printf("MENU solicitado | destino=%s | admin=%t | longitud=%d", from, admin, len(response))
		b.send(from, response)
		return
	}
	if !b.state.Match.Active && b.state.Match.Name != "" && answer(text) != "" {
		if registered && !admin {
			b.send(from, "🔒 La lista de este partido ya está cerrada. Ya no se aceptan respuestas.")
		}
		return
	}
	if registered && b.state.Match.Active {
		r := answer(text)
		if r != "" {
			m := &b.state.Match
			invited := false
			for _, n := range m.Invited {
				if clean(n) == clean(p.Number) {
					invited = true
					break
				}
			}
			if !invited {
				b.send(from, "ℹ️ No estás convocado a este partido.")
				return
			}
			if r == "SI" && b.confirmedCount() >= maxPlayers {
				if old, ok := m.Answers[p.Number]; !ok || old.Status != "SI" {
					b.send(from, "⚠️ El cupo de 10 jugadores ya está completo.")
					return
				}
			}
			previous, hadPrevious := m.Answers[p.Number]
			if hadPrevious && previous.Status == r {
				if r == "SI" {
					if previous.PaymentMethod != "" {
						b.send(from, "✅ Tu asistencia ya estaba registrada. Método de pago: "+strings.ToLower(previous.PaymentMethod)+". No hace falta responder nuevamente.")
					} else {
						b.flow[number] = "pago_metodo"
						b.send(from, "✅ Tu asistencia ya está registrada. Solo falta el método de pago:\n💳 TRANSFERENCIA (alias ezzze.mzz y luego enviá el comprobante) o 💵 EFECTIVO (pago en mano).\nRespondé TRANSFERENCIA o EFECTIVO.")
					}
				} else {
					b.send(from, "👍 Tu respuesta NO ya estaba registrada. No hace falta responder nuevamente.")
				}
				return
			}
			m.Answers[p.Number] = Answer{Number: p.Number, Name: p.Name, Status: r}
			b.save()
			if r == "SI" {
				b.flow[number] = "pago_metodo"
				b.send(from, "✅ ¡Asistencia confirmada! ¿Cómo vas a pagar?\\nRespondé TRANSFERENCIA o EFECTIVO.")
				notification := "🟢 " + p.Name + fmt.Sprintf(" confirmó asistencia (%d/%d). Falta registrar el método de pago.", b.count("SI"), maxPlayers)
				if admin {
					b.notifyOtherAdmin(number, notification)
				} else {
					b.notifyAdmins(notification)
				}
			} else {
				delete(b.flow, number)
				b.send(from, "👍 Anotado: no podés asistir.")
				notification := "🔴 " + p.Name + " respondió NO."
				if admin {
					b.notifyOtherAdmin(number, notification)
				} else {
					b.notifyAdmins(notification)
				}
			}
			if b.confirmedCount() >= maxPlayers {
				b.closeMatchLocked("se completaron los 10 lugares")
			}
			return
		}
	}
	adminCommand := admin && strings.HasPrefix(normalize(text), "!")
	if adminCommand {
		command := normalize(text)
		if command == "!atras" {
			delete(b.flow, number)
			delete(b.temp, number)
			b.send(from, "↩️ Volviste al menú principal. Escribí !menu para ver los comandos.")
			return
		}
		// Un comando nuevo interrumpe el paso anterior: evita que !MENU o !LISTA
		// se interpreten como un número de destinatario de !mensaje.
		if b.flow[number] != "" {
			delete(b.flow, number)
			delete(b.temp, number)
		}
	}
	if !adminCommand && (b.flow[number] == "pago_metodo" || (b.flow[number] == "" && registered && b.state.Match.Name != "" && b.state.Match.Answers[p.Number].Status == "SI" && b.state.Match.Answers[p.Number].PaymentMethod == "")) {
		method := normalize(strings.Trim(text, " .,!¡?¿"))
		if method == "transferencia" || method == "transferir" || method == "transf" || method == "transfer" || method == "por transferencia" || method == "transferencia bancaria" || method == "trasferencia" || method == "transferensia" || method == "transferencia alias" || method == "banco" {
			a := b.state.Match.Answers[p.Number]
			a.PaymentMethod = "TRANSFERENCIA"
			b.state.Match.Answers[p.Number] = a
			b.save()
			delete(b.flow, number)
			b.send(from, "💳 MÉTODO REGISTRADO: TRANSFERENCIA\n\nAlias: ezzze.mzz\nCuando realices la transferencia, enviá una foto del comprobante por este chat.\n📸 Te confirmaremos cuando la imagen llegue; el administrador revisará el pago.")
			b.notifyAdmins("💳 " + p.Name + " eligió TRANSFERENCIA. Falta recibir el comprobante.")
			return
		}
		if method == "efectivo" || method == "cash" || method == "en efectivo" || method == "pago en efectivo" || method == "efectivo en mano" || method == "efectibo" || method == "efectibo en mano" || method == "en mano" || method == "mano" {
			a := b.state.Match.Answers[p.Number]
			a.PaymentMethod = "EFECTIVO"
			b.state.Match.Answers[p.Number] = a
			b.save()
			delete(b.flow, number)
			b.send(from, "💵 MÉTODO REGISTRADO: EFECTIVO\nEl pago queda pendiente para realizarlo en mano el día del partido.")
			b.notifyAdmins("💵 " + p.Name + " confirmó asistencia y pagará en EFECTIVO.")
			return
		}
		b.send(from, "No pude identificar el método de pago. Elegí una opción escribiendo exactamente:\n💳 TRANSFERENCIA — alias ezzze.mzz; después enviá el comprobante.\n💵 EFECTIVO — pago en mano.")
		return
	}
	if !admin {
		// Consultas públicas: no modifican convocatorias ni el plantel.
		switch normalize(strings.TrimSpace(text)) {
		case "!lista", "!partidos":
			if b.state.Match.Name == "" {
				b.send(from, "📭 No hay partidos programados.")
			} else {
				b.send(from, b.listText())
			}
			return
		case "!jugadores":
			names := make([]string, 0, len(b.state.Players))
			for _, x := range b.state.Players {
				names = append(names, x.Name)
			}
			b.send(from, fmt.Sprintf("PLANTEL (%d/%d)\n%s", len(b.state.Players), maxRoster, orEmpty(names)))
			return
		case "!listalista":
			names := make([]string, 0, len(b.state.ListOnly))
			for _, x := range b.state.ListOnly {
				names = append(names, x.Name)
			}
			b.send(from, fmt.Sprintf("LISTA APARTE (%d)\n%s", len(names), orEmpty(names)))
			return
		}
		// La IA automática es opt-in y solo responde en conversaciones privadas.
		if b.state.AutoAI {
			go b.replyGemini(from, number, text)
		}
		// Con !ia off el bot queda en silencio: no activar respuestas locales
		// como fallback, porque eso haría parecer que la IA sigue encendida.
		return
	}
	cmd := normalize(text)
	if step := b.flow[number]; step != "" {
		b.handleFlow(from, number, step, text)
		return
	}
	switch strings.Fields(cmd)[0] {
	case "!ia":
		// La configuración !ia on/off/estado se procesa antes del parser de IA.
		b.send(from, "Usá !ia on, !ia off o !ia estado.")
	case "!confirmarpago":
		fields := strings.Fields(cmd)
		if len(fields) < 2 {
			b.flow[number] = "pago_confirmar_numero"
			b.send(from, "Escribí el número internacional del jugador que querés marcar como PAGADO, sin + ni espacios. Solo se aprobará si eligió transferencia y envió comprobante.")
			return
		}
		message, ok := b.confirmTransferPayment(fields[1])
		b.send(from, message)
		if ok && strings.HasPrefix(message, "✅") {
			b.notifyOtherAdmin(number, "💸 "+message+" Confirmado por "+adminDisplay(number)+".")
		}
	case "!rechazarpago":
		fields := strings.Fields(cmd)
		if len(fields) < 2 {
			b.flow[number] = "pago_rechazar_numero"
			b.send(from, "Escribí el número internacional del jugador cuyo pago por transferencia querés RECHAZAR, sin + ni espacios. Verificá antes que el dinero no haya ingresado.")
			return
		}
		message, ok := b.rejectTransferPayment(fields[1])
		b.send(from, message)
		if ok && strings.HasPrefix(message, "❌") {
			b.notifyOtherAdmin(number, "🚫 "+message+" Rechazado por "+adminDisplay(number)+".")
		}
	case "!menu", "!ayuda", "menu":
		b.send(from, menuText(true, false))
	case "!partidos", "!lista":
		if b.state.Match.Name == "" {
			b.send(from, "📭 No hay partidos programados.")
		} else {
			b.send(from, b.listText())
		}
	case "!partido":
		if b.state.Match.Active {
			b.send(from, "Ya hay una convocatoria activa. Usá !cancelar.")
			return
		}
		b.temp[number] = map[string]string{}
		b.flow[number] = "admin_juega"
		b.send(from, "⚽ Antes de crear el partido: ¿vos vas a jugar?\nEscribí SI o NO para registrar tu respuesta inicial.")
	case "!cancelar":
		if b.state.Match.Name == "" {
			b.send(from, "No hay partidos programados.")
			return
		}
		b.flow[number] = "cancelar_motivo"
		b.send(from, "Escribí el motivo de la cancelación. Es obligatorio.")
	case "!finalizar":
		if b.state.Match.Name == "" {
			b.send(from, "No hay partidos programados.")
			return
		}
		matchName := b.state.Match.Name
		b.state.Match = Match{Answers: map[string]Answer{}}
		b.save()
		b.send(from, "✅ Partido "+matchName+" finalizado. Se eliminó la convocatoria y la lista. No hay partidos programados.")
		b.notifyAdmins("🏁 Partido " + matchName + " marcado como finalizado. La lista fue limpiada.")
	case "!listalista":
		var names []string
		for _, x := range b.state.ListOnly {
			names = append(names, x.Name)
		}
		b.send(from, fmt.Sprintf("LISTA APARTE (%d)\n%s", len(names), orEmpty(names)))
	case "!jugadores":
		var names []string
		for _, x := range b.state.Players {
			names = append(names, x.Name+" — "+x.Number)
		}
		b.send(from, fmt.Sprintf("PLANTEL (%d/%d)\n%s", len(b.state.Players), maxRoster, strings.Join(names, "\n")))
	case "!agregar":
		if len(b.state.Players) >= maxRoster {
			b.send(from, "El plantel ya llegó al máximo de 30.")
			return
		}
		b.flow[number] = "agregar_nombre"
		b.temp[number] = map[string]string{}
		b.send(from, "Escribí el nombre del jugador.")
	case "!agregarlista":
		b.temp[number] = map[string]string{}
		b.flow[number] = "lista_nombre"
		b.send(from, "Escribí el nombre de la persona para agregar a la lista aparte.")
	case "!quitarlista":
		b.flow[number] = "quitarlista_nombre"
		b.send(from, "Escribí el nombre exacto de la persona que querés quitar de la lista aparte. Si está confirmada manualmente en el partido, también se quitará de CONFIRMADOS y liberará un cupo.")
	case "!mensaje":
		b.temp[number] = map[string]string{}
		b.flow[number] = "mensaje_destino"
		b.send(from, "¿A quién se lo envío? Elegí una opción escribiendo:\nTODOS\nPENDIENTES (faltan confirmar)\nCONFIRMADOS (respondieron SI)\nO escribí un número registrado.")
	case "!bloquear":
		b.flow[number] = "bloquear_numero"
		b.send(from, "Escribí el número internacional que querés bloquear, sin + ni espacios. Ese número no recibirá convocatorias ni mensajes del bot, y el bot ignorará sus mensajes.")
	case "!desbloquear":
		b.flow[number] = "desbloquear_numero"
		b.send(from, "Escribí el número internacional que querés desbloquear, sin + ni espacios.")
	case "!bloqueados":
		if len(b.state.Blocked) == 0 {
			b.send(from, "🔓 No hay números bloqueados.")
		} else {
			b.send(from, fmt.Sprintf("⛔ NÚMEROS BLOQUEADOS (%d)\n%s", len(b.state.Blocked), strings.Join(b.state.Blocked, "\n")))
		}
	case "!modocharla":
		b.state.ChatMode = true
		b.save()
		b.send(from, "🗣️ Modo charla ACTIVADO. Voy a responder mensajes del grupo con respuestas locales. Para apagarlo: !callate")
	case "!callate":
		b.state.ChatMode = false
		b.state.JokeMode = false
		b.save()
		b.send(from, "🤐 Modo charla DESACTIVADO. Solo responderé comandos y mensajes privados habituales.")
	case "!llegotupapariber":
		b.state.ChatMode = true
		b.state.JokeMode = true
		b.save()
		b.send(from, "😂 Modo broma activado en este grupo. Si querés apagarlo, usá !callate.")
	case "!sacar":
		fields := strings.Fields(cmd)
		if len(fields) < 2 {
			b.flow[number] = "sacar_partido_numero"
			b.send(from, "Escribí el número internacional del jugador que querés sacar SOLO de la lista del partido. No se elimina del plantel.")
			return
		}
		n := clean(fields[1])
		if len(n) < 10 || len(n) > 15 {
			b.send(from, "Uso: !sacar 549XXXXXXXXX")
			return
		}
		if isAdmin(n) {
			b.send(from, "No se puede sacar a un administrador de la convocatoria.")
			return
		}
		player, removed, exists := b.removePlayerFromCurrentMatchLocked(n)
		if !exists {
			b.send(from, "No encontré ese número en el plantel o no hay un partido activo/programado.")
			return
		}
		if !removed {
			b.send(from, "ℹ️ "+player.Name+" pertenece al plantel, pero no estaba en la convocatoria actual.")
			return
		}
		b.send(from, "✅ "+player.Name+" fue quitado/a solamente de la lista del partido. Sigue en el plantel y el partido continúa.")
		b.sendToPhone(n, "ℹ️ Ya no figurás en la convocatoria del partido actual. Seguís en el plantel del equipo.")
		b.notifyAdmins("➖ " + player.Name + " fue quitado/a de la convocatoria actual; permanece en el plantel.\n" + b.progressText())
	case "!quitar":
		b.flow[number] = "quitar_numero"
		b.send(from, "Escribí el número del jugador que querés quitar.")
	default:
		// En chats privados, también el administrador puede conversar con la IA
		// cuando la activó explícitamente con !ia on. Los comandos (prefijo !)
		// nunca se envían al modelo y !ia off deja el bot en silencio.
		if b.state.AutoAI && !strings.HasPrefix(cmd, "!") {
			log.Printf("IA_AUTO_ADMIN | numero=%s | contexto=privado", number)
			go b.replyGemini(from, number, text)
		}
	}
}

// removePlayerFromCurrentMatchLocked quita a un jugador solo de la convocatoria actual.
// No modifica b.state.Players: el jugador sigue perteneciendo al plantel.
func (b *Bot) removePlayerFromCurrentMatchLocked(number string) (Player, bool, bool) {
	n := clean(number)
	if n == "" || (!b.state.Match.Active && b.state.Match.Name == "") {
		return Player{}, false, false
	}
	player, found := b.find(n)
	if !found {
		return Player{}, false, false
	}
	wasInvited := false
	invited := make([]string, 0, len(b.state.Match.Invited))
	for _, invitedNumber := range b.state.Match.Invited {
		if clean(invitedNumber) == n {
			wasInvited = true
			continue
		}
		invited = append(invited, invitedNumber)
	}
	_, hadAnswer := b.state.Match.Answers[n]
	if !wasInvited && !hadAnswer {
		return player, false, true
	}
	b.state.Match.Invited = invited
	delete(b.state.Match.Answers, n)
	b.save()
	return player, true, true
}

func (b *Bot) handleFlow(from types.JID, number, step, text string) {
	tmp := b.temp[number]
	if tmp == nil {
		tmp = map[string]string{}
		b.temp[number] = tmp
	}
	switch step {
	case "pago_confirmar_numero":
		delete(b.flow, number)
		message, ok := b.confirmTransferPayment(text)
		b.send(from, message)
		if ok && strings.HasPrefix(message, "✅") {
			b.notifyOtherAdmin(number, "💸 "+message+" Confirmado por "+adminDisplay(number)+".")
		}
	case "pago_rechazar_numero":
		delete(b.flow, number)
		message, ok := b.rejectTransferPayment(text)
		b.send(from, message)
		if ok && strings.HasPrefix(message, "❌") {
			b.notifyOtherAdmin(number, "🚫 "+message+" Rechazado por "+adminDisplay(number)+".")
		}
	case "bloquear_numero":
		n := clean(text)
		if len(n) < 10 {
			b.send(from, "Número inválido. Escribí el número internacional completo, sin + ni espacios.")
			return
		}
		if isAdmin(n) {
			b.send(from, "🔒 No se puede bloquear a un administrador.")
			delete(b.flow, number)
			return
		}
		for _, old := range b.state.Blocked {
			if clean(old) == n {
				b.send(from, "Ese número ya estaba bloqueado.")
				delete(b.flow, number)
				return
			}
		}
		b.state.Blocked = append(b.state.Blocked, n)
		// Quitar de plantel, lista aparte y convocatoria para que no vuelva a recibir avisos.
		players := b.state.Players[:0]
		for _, p := range b.state.Players {
			if clean(p.Number) != n {
				players = append(players, p)
			}
		}
		b.state.Players = players
		listOnly := b.state.ListOnly[:0]
		for _, p := range b.state.ListOnly {
			if clean(p.Number) != n {
				listOnly = append(listOnly, p)
			}
		}
		b.state.ListOnly = listOnly
		invited := b.state.Match.Invited[:0]
		for _, v := range b.state.Match.Invited {
			if clean(v) != n {
				invited = append(invited, v)
			}
		}
		b.state.Match.Invited = invited
		delete(b.state.Match.Answers, n)
		b.save()
		delete(b.flow, number)
		b.send(from, "⛔ Número "+n+" bloqueado. El bot ya no le responderá ni le enviará convocatorias.")
	case "desbloquear_numero":
		n := clean(text)
		if len(n) < 10 {
			b.send(from, "Número inválido. Escribí el número internacional completo, sin + ni espacios.")
			return
		}
		found := false
		kept := make([]string, 0, len(b.state.Blocked))
		for _, old := range b.state.Blocked {
			if clean(old) == n {
				found = true
				continue
			}
			kept = append(kept, old)
		}
		b.state.Blocked = kept
		b.save()
		delete(b.flow, number)
		if found {
			b.send(from, "🔓 Número "+n+" desbloqueado. Para volver a recibir convocatorias, agregalo nuevamente al plantel con !agregar.")
		} else {
			b.send(from, "Ese número no estaba en la lista de bloqueados.")
		}
	case "cancelar_motivo":
		if strings.TrimSpace(text) == "" {
			b.send(from, "El motivo es obligatorio. Escribilo para confirmar la cancelación.")
			return
		}
		matchName := b.state.Match.Name
		invited := append([]string(nil), b.state.Match.Invited...)
		for _, n := range invited {
			if !b.isBlocked(n) {
				b.sendToPhone(n, "🛑 Se canceló el partido "+matchName+". Motivo: "+text)
			}
		}
		b.state.Match = Match{Answers: map[string]Answer{}}
		b.save()
		b.notifyAdmins("🛑 Partido " + matchName + " cancelado. Motivo: " + text + ". Se eliminó la convocatoria y la lista.")
		b.send(from, "✅ Partido cancelado. Se eliminó la convocatoria y la lista. No hay partidos programados.")
		delete(b.flow, number)
	case "mensaje_destino":
		target := normalize(strings.TrimSpace(text))
		switch target {
		case "todos", "pendientes", "pendiente", "faltan confirmar", "faltan responder", "confirmados", "confirmado", "ya confirmaron", "numero", "número":
			if target == "pendiente" || target == "faltan confirmar" || target == "faltan responder" {
				target = "pendientes"
			}
			if target == "confirmado" || target == "ya confirmaron" {
				target = "confirmados"
			}
			if target == "número" {
				target = "numero"
			}
		default:
			target = clean(text)
			if _, ok := b.findAny(target); !ok {
				b.send(from, "No encuentro ese número. Elegí TODOS, PENDIENTES, CONFIRMADOS o escribí un número registrado.")
				return
			}
		}
		tmp["destino"] = target
		b.flow[number] = "mensaje_texto"
		b.send(from, "Escribí el mensaje que querés enviar.")
	case "mensaje_texto":
		target := normalize(tmp["destino"])
		count := 0
		recipients := []string{}
		seen := map[string]bool{}
		add := func(n string) {
			n = clean(n)
			if n != "" && !seen[n] {
				seen[n] = true
				recipients = append(recipients, n)
			}
		}
		switch target {
		case "todos":
			for _, p := range append(append([]Player{}, b.state.Players...), b.state.ListOnly...) {
				add(p.Number)
			}
		case "pendientes", "confirmados":
			if !b.state.Match.Active && b.state.Match.Name == "" {
				b.send(from, "No hay un partido cargado para identificar pendientes o confirmados.")
				return
			}
			for _, n := range b.state.Match.Invited {
				a, answered := b.state.Match.Answers[clean(n)]
				if target == "pendientes" && !answered {
					add(n)
				}
				if target == "confirmados" && answered && a.Status == "SI" {
					add(n)
				}
			}
		default:
			add(tmp["destino"])
		}
		failed := 0
		for _, n := range recipients {
			if b.isBlocked(n) {
				continue
			}
			// Resolver el número con WhatsApp para usar el JID vigente (PN o LID).
			if b.sendToPhone(n, "📢 MENSAJE DE ADMINISTRACIÓN\n"+text) {
				count++
			} else {
				failed++
			}
		}
		if failed > 0 {
			b.send(from, fmt.Sprintf("⚠️ WhatsApp aceptó %d envíos; %d destinatarios no pudieron verificarse o recibieron error. Revisá la conexión y los registros de Termux.", count, failed))
		} else {
			b.send(from, fmt.Sprintf("📨 WhatsApp aceptó la solicitud de envío a %d destinatario(s). La entrega se confirmará cuando llegue el recibo de WhatsApp.", count))
		}
		delete(b.flow, number)
		delete(b.temp, number)
	case "lista_nombre":
		name := strings.TrimSpace(text)
		if name == "" {
			b.send(from, "El nombre no puede estar vacío. Escribí el nombre de la persona.")
			return
		}
		for _, x := range b.state.ListOnly {
			if normalize(x.Name) == normalize(name) {
				b.send(from, "Esa persona ya está en la lista aparte.")
				delete(b.flow, number)
				delete(b.temp, number)
				return
			}
		}
		person := Player{Name: name} // Sin número: no se guarda un teléfono ni se crea un contacto.
		b.state.ListOnly = append(b.state.ListOnly, person)
		addedToActiveMatch := false
		if b.state.Match.Active {
			already := false
			for _, existing := range b.state.Match.ListOnlyNames {
				if normalize(existing) == normalize(name) {
					already = true
					break
				}
			}
			if !already && b.confirmedCount() < maxPlayers {
				b.state.Match.ListOnlyNames = append(b.state.Match.ListOnlyNames, name)
				addedToActiveMatch = true
			}
		}
		if b.state.Match.Active && b.confirmedCount() >= maxPlayers {
			b.closeMatchLocked("se completaron los 10 lugares")
		}
		b.save()
		delete(b.flow, number)
		delete(b.temp, number)
		if addedToActiveMatch {
			b.send(from, "✅ "+name+" fue agregado/a a la lista aparte y a la lista del partido activo. No se guardó ningún número ni se envió ningún mensaje privado.")
		} else if b.state.Match.Active && b.confirmedCount() >= maxPlayers {
			b.send(from, "✅ "+name+" fue agregado/a a la lista aparte, pero el partido ya tiene 10 confirmados y no se agregó a ese partido.")
		} else {
			b.send(from, "✅ "+name+" fue agregado/a a la lista aparte. No se guardó ningún número ni se envió ningún mensaje privado.")
		}
	case "quitarlista_nombre":
		name := strings.TrimSpace(text)
		if name == "" {
			b.send(from, "El nombre no puede estar vacío. Escribí el nombre de la persona que querés quitar.")
			return
		}
		key := normalize(name)
		removedSaved := false
		keptPeople := make([]Player, 0, len(b.state.ListOnly))
		for _, person := range b.state.ListOnly {
			if normalize(person.Name) == key {
				removedSaved = true
				continue
			}
			keptPeople = append(keptPeople, person)
		}
		b.state.ListOnly = keptPeople
		removedMatch := false
		keptNames := make([]string, 0, len(b.state.Match.ListOnlyNames))
		for _, personName := range b.state.Match.ListOnlyNames {
			if normalize(personName) == key {
				removedMatch = true
				continue
			}
			keptNames = append(keptNames, personName)
		}
		b.state.Match.ListOnlyNames = keptNames
		delete(b.flow, number)
		delete(b.temp, number)
		if !removedSaved && !removedMatch {
			b.send(from, "No encontré a esa persona en la lista aparte ni entre los confirmados manualmente del partido.")
			return
		}
		b.save()
		if b.state.Match.Active && removedMatch {
			b.notifyAdmins("➖ " + name + " fue quitado/a de los confirmados manuales. Se liberó un cupo.\n" + b.progressText())
		}
		b.send(from, "✅ "+name+" fue quitado/a de la lista aparte"+func() string {
			if removedMatch {
				return " y de CONFIRMADOS del partido"
			}
			return ""
		}()+". El cupo quedó liberado si estaba ocupándolo.")
	case "admin_juega":
		r := answer(text)
		if r != "SI" && r != "NO" {
			b.send(from, "Respondé escribiendo SI o NO para registrar si vas a jugar.")
			return
		}
		tmp["admin_juega"] = r
		b.flow[number] = "nombre"
		b.send(from, "Perfecto. ¿Qué nombre tendrá el partido?")
	case "nombre":
		tmp["nombre"] = text
		b.flow[number] = "lugar"
		b.send(from, "¿En qué cancha o lugar?")
	case "lugar":
		tmp["lugar"] = text
		b.flow[number] = "dia"
		b.send(from, "¿Qué día será el partido? Escribí la fecha como DD/MM/AAAA (por ejemplo 18/11/2026). También podés poner HOY o MAÑANA.")
	case "dia":
		tmp["dia"] = strings.TrimSpace(text)
		b.flow[number] = "hora"
		b.send(from, "¿A qué hora será? Usá formato 24 horas, por ejemplo 22:30.")
	case "hora":
		if _, err := parseMatchDate(tmp["dia"], text, time.Now()); err != nil {
			b.send(from, "No pude reconocer la fecha o la hora. Fecha: DD/MM/AAAA y hora: HH:MM (ejemplo 18/11/2026 y 22:30). Volvé a escribir la hora.")
			return
		}
		tmp["hora"] = strings.TrimSpace(text)
		kickoff, _ := parseMatchDate(tmp["dia"], tmp["hora"], time.Now())
		if !kickoff.Add(-20 * time.Minute).After(time.Now()) {
			b.send(from, "Esa hora ya pasó o faltan menos de 20 minutos. No puedo abrir una convocatoria que ya debería estar cerrada. Escribí otra hora.")
			return
		}
		b.flow[number] = "costo"
		b.send(from, "¿Cuánto paga cada jugador?")
	case "costo":
		tmp["costo"] = text
		kickoff, parseErr := parseMatchDate(tmp["dia"], tmp["hora"], time.Now())
		if parseErr != nil {
			b.send(from, "No pude interpretar la fecha y hora del partido. Cancelé la creación; volvé a usar !partido y cargá fecha DD/MM/AAAA y hora HH:MM.")
			delete(b.flow, number)
			delete(b.temp, number)
			return
		}
		created := time.Now()
		closeAt := kickoff.Add(-20 * time.Minute)
		expiresAt := created.Add(5 * time.Hour)
		if closeAt.Before(expiresAt) {
			expiresAt = closeAt
		}
		m := Match{Active: true, Name: tmp["nombre"], Place: tmp["lugar"], Day: tmp["dia"], Hour: tmp["hora"], Cost: tmp["costo"], Answers: map[string]Answer{}, CreatedAt: created, ExpiresAt: expiresAt, KickoffAt: kickoff}
		// Todos los integrantes del plantel, incluidos ambos administradores, reciben convocatoria.
		for _, p := range b.state.Players {
			m.Invited = append(m.Invited, p.Number)
		}
		// La respuesta inicial del administrador que creó el partido queda registrada.
		if creator, ok := b.find(number); ok {
			if r := tmp["admin_juega"]; r == "SI" || r == "NO" {
				m.Answers[creator.Number] = Answer{Number: creator.Number, Name: creator.Name, Status: r}
			}
		}
		b.state.Match = m

		delete(b.flow, number)
		delete(b.temp, number)
		b.save()
		b.send(from, fmt.Sprintf("Convocatoria creada. Se avisará a %d integrantes del plantel. Cupo máximo: %d.", len(m.Invited)-1, maxPlayers))
		if a, ok := m.Answers[clean(number)]; ok && a.Status == "SI" {
			b.flow[number] = "pago_metodo"
			b.send(from, "✅ Registré que jugás. ¿Cómo vas a pagar? Respondé TRANSFERENCIA o EFECTIVO.")
			b.notifyOtherAdmin(number, "🟢 "+a.Name+" confirmó asistencia al partido "+m.Name+". Falta registrar el método de pago.")
		}
		go b.broadcast(m, number)
	case "agregar_nombre":
		tmp["nombre"] = text
		b.flow[number] = "agregar_numero"
		b.send(from, "Escribí el número internacional, sin +.")
	case "agregar_numero":
		n := clean(text)
		if len(n) < 10 {
			b.send(from, "Número inválido. Probá nuevamente.")
			return
		}
		if _, ok := b.find(n); ok {
			b.send(from, "Ese número ya está registrado.")
			delete(b.flow, number)
			return
		}
		if len(b.state.Players) >= maxRoster {
			b.send(from, "Plantel completo (30 jugadores).")
			delete(b.flow, number)
			return
		}
		newPlayer := Player{n, strings.TrimSpace(tmp["nombre"])}
		b.state.Players = append(b.state.Players, newPlayer)
		addedToActiveMatch := false
		if b.state.Match.Active {
			// Add the new player to the already active invitation without recreating the match.
			alreadyInvited := false
			for _, invitedNumber := range b.state.Match.Invited {
				if clean(invitedNumber) == n {
					alreadyInvited = true
					break
				}
			}
			if !alreadyInvited && b.confirmedCount() < maxPlayers {
				b.state.Match.Invited = append(b.state.Match.Invited, n)
				addedToActiveMatch = true
			}
		}
		b.save()
		delete(b.flow, number)
		delete(b.temp, number)
		if addedToActiveMatch {
			b.send(from, "✅ "+newPlayer.Name+" fue agregado al plantel y a la convocatoria activa. Ya le estoy enviando el partido.")
			activeMatch := b.state.Match
			go b.sendMatchInvitation(n, activeMatch)
			b.notifyAdmins("📨 Se agregó a " + newPlayer.Name + " a la convocatoria activa y se le envió el partido.")
		} else if b.state.Match.Active && b.confirmedCount() >= maxPlayers {
			b.send(from, "✅ Jugador agregado al plantel, pero el partido activo ya completó los 10 lugares. No se envió convocatoria.")
		} else {
			b.send(from, "✅ Jugador agregado al plantel. No hay una convocatoria activa para enviar.")
		}
	case "sacar_partido_numero":
		n := clean(text)
		if len(n) < 10 || len(n) > 15 {
			b.send(from, "Número inválido. Escribí el número internacional completo, sin + ni espacios.")
			return
		}
		if isAdmin(n) {
			b.send(from, "No se puede sacar a un administrador de la convocatoria.")
			delete(b.flow, number)
			return
		}
		player, removed, exists := b.removePlayerFromCurrentMatchLocked(n)
		delete(b.flow, number)
		if !exists {
			b.send(from, "No encontré ese número en el plantel o no hay un partido activo/programado.")
			return
		}
		if !removed {
			b.send(from, "ℹ️ "+player.Name+" pertenece al plantel, pero no estaba en la convocatoria actual.")
			return
		}
		b.send(from, "✅ "+player.Name+" fue quitado/a solamente de la lista del partido. Sigue en el plantel y el partido continúa.")
		b.sendToPhone(n, "ℹ️ Ya no figurás en la convocatoria del partido actual. Seguís en el plantel del equipo.")
		b.notifyAdmins("➖ " + player.Name + " fue quitado/a de la convocatoria actual; permanece en el plantel.\n" + b.progressText())
	case "quitar_numero":
		n := clean(text)
		if len(n) < 10 {
			b.send(from, "Número inválido. Escribí el número internacional sin + ni espacios.")
			return
		}
		if isAdmin(n) {
			b.send(from, "No se puede quitar a ninguno de los administradores.")
			delete(b.flow, number)
			return
		}
		var removedPlayer Player
		found := false
		players := make([]Player, 0, len(b.state.Players))
		for _, player := range b.state.Players {
			if clean(player.Number) == n {
				removedPlayer = player
				found = true
				continue
			}
			players = append(players, player)
		}
		if !found {
			b.send(from, "No encontré ese número en el plantel.")
			delete(b.flow, number)
			return
		}
		// Si tenía convocatoria activa, quitarlo también de invitados y respuestas
		// para que no siga figurando ni ocupe uno de los 10 lugares.
		wasInvited := false
		invited := make([]string, 0, len(b.state.Match.Invited))
		for _, invitedNumber := range b.state.Match.Invited {
			if clean(invitedNumber) == n {
				wasInvited = true
				continue
			}
			invited = append(invited, invitedNumber)
		}
		b.state.Match.Invited = invited
		_, hadAnswer := b.state.Match.Answers[n]
		delete(b.state.Match.Answers, n)
		b.state.Players = players
		b.save()
		delete(b.flow, number)
		delete(b.temp, number)
		// Aviso privado al número que fue eliminado, sin afectar la sesión ni el resto del plantel.
		privateNotice := "ℹ️ Fuiste eliminado/a del plantel del equipo. Si creés que fue un error, comunicate con el administrador."
		if wasInvited {
			privateNotice = "ℹ️ Fuiste eliminado/a del plantel del equipo y de la convocatoria del partido activo. Si creés que fue un error, comunicate con el administrador."
		}
		b.sendToPhone(removedPlayer.Number, privateNotice)
		b.send(from, "✅ "+removedPlayer.Name+" fue eliminado/a del plantel.")
		if b.state.Match.Active && wasInvited {
			b.notifyAdmins("➖ " + removedPlayer.Name + " fue eliminado/a del plantel y de la convocatoria." + func() string {
				if hadAnswer {
					return " Se eliminó su respuesta y se liberó el cupo si había confirmado."
				}
				return ""
			}() + "\n" + b.progressText())
		} else {
			b.notifyAdmins("➖ " + removedPlayer.Name + " fue eliminado/a del plantel.")
		}
	}
}
func (b *Bot) sendMatchInvitation(number string, m Match) {
	// Resolver el número con WhatsApp para usar el JID vigente (PN o LID).
	b.sendToPhone(number, fmt.Sprintf("⚽ ¡NUEVO PARTIDO!\n\n🏆 Partido: %s\n📍 Lugar: %s\n📅 Fecha: %s\n🕒 Hora: %s\n💰 Costo: %s\n\n¿Vas a jugar?\nRespondé *SI* para confirmar o *NO* para rechazar.\nCupo máximo: %d jugadores.", m.Name, m.Place, m.Day, m.Hour, m.Cost, maxPlayers))
}

func (b *Bot) broadcast(m Match, creatorNumber string) {
	for _, n := range m.Invited {
		// El creador ya respondió SI/NO al iniciar !partido; no repetirle la pregunta.
		if clean(n) == clean(creatorNumber) || b.isBlocked(n) {
			continue
		}
		b.sendMatchInvitation(n, m)
		time.Sleep(700 * time.Millisecond)
	}
}
func (b *Bot) resolveNumber(info types.MessageInfo) string {
	// Prefer the alternate PN supplied by WhatsApp for LID-addressed messages.
	if !info.SenderAlt.IsEmpty() && info.SenderAlt.Server == types.DefaultUserServer {
		return clean(info.SenderAlt.User)
	}
	sender := info.Sender
	if sender.Server == types.HiddenUserServer {
		pn, err := b.client.Store.LIDs.GetPNForLID(context.Background(), sender)
		if err == nil && !pn.IsEmpty() {
			return clean(pn.User)
		}
	}
	if sender.Server == types.DefaultUserServer {
		return clean(sender.User)
	}
	return clean(info.Chat.User)
}

// unwrapIncomingMessage elimina envoltorios que WhatsApp puede agregar a un
// mensaje (efímero, ver una vez, editado o enviado desde otro dispositivo).
// Así los comandos de texto se detectan igual en chats privados y grupos.
func unwrapIncomingMessage(msg *waProto.Message) *waProto.Message {
	for depth := 0; msg != nil && depth < 8; depth++ {
		pm := msg.ProtoReflect()
		fields := pm.Descriptor().Fields()
		var next *waProto.Message
		for _, name := range []protoreflect.Name{
			"ephemeralMessage", "viewOnceMessage", "viewOnceMessageV2",
			"viewOnceMessageV2Extension", "editedMessage",
			"documentWithCaptionMessage", "deviceSentMessage",
		} {
			fd := fields.ByName(name)
			if fd == nil || !pm.Has(fd) || fd.Kind() != protoreflect.MessageKind {
				continue
			}
			wrapper := pm.Get(fd).Message()
			if !wrapper.IsValid() {
				continue
			}
			mf := wrapper.Descriptor().Fields().ByName("message")
			if mf == nil || !wrapper.Has(mf) || mf.Kind() != protoreflect.MessageKind {
				continue
			}
			if nested, ok := wrapper.Get(mf).Message().Interface().(*waProto.Message); ok && nested != nil {
				next = nested
				break
			}
		}
		if next == nil {
			return msg
		}
		msg = next
	}
	return msg
}

func extractIncomingText(msg *waProto.Message) string {
	msg = unwrapIncomingMessage(msg)
	if msg == nil {
		return ""
	}
	if body := msg.GetConversation(); body != "" {
		return body
	}
	if extended := msg.GetExtendedTextMessage(); extended != nil {
		return extended.GetText()
	}
	if image := msg.GetImageMessage(); image != nil {
		return image.GetCaption()
	}
	if video := msg.GetVideoMessage(); video != nil {
		return video.GetCaption()
	}
	if document := msg.GetDocumentMessage(); document != nil {
		return document.GetCaption()
	}
	if buttons := msg.GetButtonsResponseMessage(); buttons != nil {
		switch buttons.GetSelectedButtonID() {
		case "ASISTENCIA_SI":
			return "SI"
		case "ASISTENCIA_NO":
			return "NO"
		}
	}
	return ""
}

func (b *Bot) onEvent(evt interface{}) {
	// Registrar recibos de WhatsApp antes de filtrar los mensajes entrantes.
	// SendMessage confirma aceptación del servidor; estos eventos confirman
	// entrega/lectura en el destinatario.
	if receipt, ok := evt.(*events.Receipt); ok {
		// En whatsmeow, ReceiptTypeDelivered se representa con una cadena vacía.
		// No confundir "sender" (acuse del dispositivo emisor) con entrega.
		status := strings.ToLower(strings.TrimSpace(string(receipt.Type)))
		label := "DESCONOCIDO"
		switch status {
		case "":
			label = "ENTREGADO"
		case "sender":
			label = "ACUSE_DEL_EMISOR"
		case "read", "read-self":
			label = "LEIDO"
		case "played":
			label = "REPRODUCIDO"
		default:
			label = strings.ToUpper(status)
		}
		for _, id := range receipt.MessageIDs {
			log.Printf("RECIBO_WHATSAPP | estado=%s | tipo_original=%q | chat=%s | remitente=%s | id=%s | hora=%s", label, status, receipt.Chat, receipt.Sender, id, receipt.Timestamp.Format(time.RFC3339))
		}
		return
	}
	m, ok := evt.(*events.Message)
	if !ok {
		return
	}
	message := unwrapIncomingMessage(m.Message)
	body := extractIncomingText(message)
	// El número propio puede ejecutar comandos desde el teléfono vinculado,
	// pero el bot ignora sus mensajes normales y nunca procesa sus respuestas.
	if m.Info.IsFromMe && !isBotCommand(body) {
		return
	}
	if m.Info.IsFromMe && isBotCommand(body) {
		self := b.resolveNumber(m.Info)
		if self == "" {
			self = clean(b.ownNumber)
		}
		if clean(self) == clean(b.ownNumber) && clean(self) != "" {
			admins = appendAdminOnce(admins, self)
		}
	}
	// Reinicia la ventana de presencia: en línea ahora y desconectado tras 20 s sin mensajes.
	if !m.Info.IsFromMe {
		b.showOnlineFor20Seconds()
	}
	// Marca como leído cada mensaje entrante (texto, imagen y mensajes de grupo).
	if b.client != nil && m.Info.ID != "" {
		if err := b.client.MarkRead(context.Background(), []types.MessageID{m.Info.ID}, m.Info.Timestamp, m.Info.Chat, m.Info.Sender); err != nil {
			log.Printf("AVISO lectura mensaje %s: %v", m.Info.ID, err)
		}
	}
	number := b.resolveNumber(m.Info)
	if m.Info.IsFromMe {
		number = clean(b.ownNumber)
	}
	if !m.Info.IsFromMe {
		b.reactToPhoto(m, message)
	}
	// PRIORIDAD ABSOLUTA: si el mensaje pide un sticker, procesarlo antes de
	// pagos, comprobantes, respuestas IA o cualquier otro flujo pendiente.
	if b.handleStickerCommand(m.Info.Chat, m.Info.Sender, number, message, body) {
		return
	}
	if b.handleStickerChoice(m.Info.Chat, number, body) {
		return
	}
	if b.handleRandomAudio(m, message) {
		return
	}
	if !m.Info.IsGroup {
		b.rememberMessage(number, m.Info.Chat.String(), string(m.Info.ID), body, m.Info.Timestamp)
	}
	if isAudioForwardCommand(body) && !isAdmin(number) {
		b.send(m.Info.Chat, "🔒 El comando !audio es exclusivo de administradores.")
		return
	}
	if isAdmin(number) && b.handleAudioForwardNumber(m.Info.Chat, number, body) {
		return
	}
	if b.handleDownloadChoice(m.Info.Chat, m.Info.Sender, body) {
		return
	}
	if b.handleIACommand(m.Info.Chat, number, body) {
		return
	}
	if isAdmin(number) && !m.Info.IsGroup && strings.TrimSpace(body) != "" {
		fields := strings.Fields(strings.TrimSpace(body))
		command := normalize(fields[0])
		if command == "!ultimos" {
			limit, target := 20, number
			if len(fields) >= 2 {
				if n, err := strconv.Atoi(fields[1]); err == nil {
					limit = n
				} else {
					target = clean(fields[1])
				}
			}
			if len(fields) >= 3 {
				target = clean(fields[2])
			}
			if len(target) < 10 {
				b.send(m.Info.Chat, "Uso: !ultimos 20 549XXXXXXXXX")
				return
			}
			b.mu.Lock()
			if b.historyTarget == nil {
				b.historyTarget = make(map[string]string)
			}
			b.historyTarget[clean(number)] = target
			b.mu.Unlock()
			b.sendRecentMessages(m.Info.Chat, target, limit)
			return
		}
		if command == "!responder" {
			// Formato: !responder INDICE TEXTO (después de !ultimos)
			// o !responder INDICE NUMERO TEXTO. También se conserva la respuesta citada.
			if len(fields) >= 3 {
				if _, err := strconv.Atoi(fields[1]); err == nil {
					idx, _ := strconv.Atoi(fields[1])
					target := ""
					textStart := 2
					if len(fields) >= 4 && len(clean(fields[2])) >= 10 {
						target = clean(fields[2])
						textStart = 3
					} else {
						b.mu.Lock()
						if b.historyTarget != nil {
							target = b.historyTarget[clean(number)]
						}
						b.mu.Unlock()
					}
					if target == "" {
						b.send(m.Info.Chat, "Primero consultá !ultimos 20 NUMERO, o usá !responder INDICE NUMERO TEXTO.")
						return
					}
					responseText := strings.TrimSpace(strings.Join(fields[textStart:], " "))
					b.replyIndexedMessage(m.Info.Chat, target, idx, responseText)
					return
				}
			}
			responseText := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(body), fields[0]))
			b.replyQuotedMessage(m.Info.Chat, quotedStanzaID(m.Message), responseText)
			return
		}
	}
	// Despachar los menús antes que IA/RPG/estados de conversación.
	// Así !menu, !allmenu y /menu no pueden ser consumidos por otro módulo.
	if response, matched := menuResponse(body, isAdmin(number)); matched {
		log.Printf("MENU_DISPATCH | comando=%q | destino=%s | admin=%t | caracteres=%d", strings.TrimSpace(body), m.Info.Chat, isAdmin(number), len(response))
		b.send(m.Info.Chat, response)
		return
	}
	if provider, prompt, ok := parseNexusAICommand(body); ok {
		go b.replyNexusAI(m.Info.Chat, provider, prompt)
		return
	}
	if b.handleNexusRPG(m.Info.Chat, number, body) {
		return
	}
	b.mu.Lock()
	blocked := b.isBlocked(number)
	b.mu.Unlock()
	if blocked {
		log.Printf("IGNORADO | número bloqueado | %s", number)
		return
	}
	if b.handleDownloadCommand(m.Info.Chat, m.Info.Sender, body) {
		return
	}
	if b.handleAudioForwardCommand(m.Info.Chat, number, message, body) {
		return
	}
	if m.Info.IsGroup {
		text := strings.TrimSpace(body)
		if text == "" {
			return
		}
		command := normalize(text)
		admin := isAdmin(number)
		if strings.HasPrefix(command, "!sacar ") || command == "!sacar" {
			if !admin {
				b.send(m.Info.Chat, "🔒 Este comando es solo para administradores.")
				return
			}
			fields := strings.Fields(text)
			if len(fields) < 2 {
				b.send(m.Info.Chat, "Uso: !sacar 549XXXXXXXXX. Quita al jugador solo de la lista del partido; no del plantel.")
				return
			}
			n := clean(fields[1])
			if len(n) < 10 || len(n) > 15 || isAdmin(n) {
				b.send(m.Info.Chat, "Número inválido o administrador protegido. Uso: !sacar 549XXXXXXXXX")
				return
			}
			b.mu.Lock()
			player, removed, exists := b.removePlayerFromCurrentMatchLocked(n)
			if exists && removed {
				progress := b.progressText()
				b.mu.Unlock()
				b.send(m.Info.Chat, "✅ "+player.Name+" fue quitado/a solamente de la lista del partido. Sigue en el plantel y el partido continúa.")
				b.sendToPhone(n, "ℹ️ Ya no figurás en la convocatoria del partido actual. Seguís en el plantel del equipo.")
				b.notifyAdmins("➖ " + player.Name + " fue quitado/a de la convocatoria actual; permanece en el plantel.\n" + progress)
			} else {
				b.mu.Unlock()
				if !exists {
					b.send(m.Info.Chat, "No encontré ese número en el plantel o no hay un partido activo/programado.")
				} else {
					b.send(m.Info.Chat, "ℹ️ "+player.Name+" pertenece al plantel, pero no estaba en la convocatoria actual.")
				}
			}
			return
		}
		switch command {
		case "!lista", "!partidos":
			b.mu.Lock()
			if b.state.Match.Name == "" {
				b.send(m.Info.Chat, "📭 No hay partidos programados.")
			} else {
				b.send(m.Info.Chat, b.listText())
			}
			b.mu.Unlock()
			return
		case "!jugadores":
			b.mu.Lock()
			names := make([]string, 0, len(b.state.Players))
			for _, x := range b.state.Players {
				names = append(names, x.Name)
			}
			b.send(m.Info.Chat, fmt.Sprintf("PLANTEL (%d/%d)\n%s", len(b.state.Players), maxRoster, orEmpty(names)))
			b.mu.Unlock()
			return
		case "!listalista":
			b.mu.Lock()
			names := make([]string, 0, len(b.state.ListOnly))
			for _, x := range b.state.ListOnly {
				names = append(names, x.Name)
			}
			b.send(m.Info.Chat, fmt.Sprintf("LISTA APARTE (%d)\n%s", len(names), orEmpty(names)))
			b.mu.Unlock()
			return
		}
		if response, ok := menuResponse(text, admin); ok {
			log.Printf("MENU solicitado en grupo | destino=%s | admin=%t | longitud=%d", m.Info.Chat, admin, len(response))
			b.send(m.Info.Chat, response)
			return
		}
		b.mu.Lock()
		chatMode, jokeMode := b.state.ChatMode, b.state.JokeMode
		b.mu.Unlock()
		if admin && command == "!modocharla" {
			b.mu.Lock()
			b.state.ChatMode = true
			b.save()
			b.mu.Unlock()
			b.send(m.Info.Chat, "🗣️ Modo charla ACTIVADO. Responderé mensajes del grupo. Para apagarlo: !callate")
			return
		}
		if admin && command == "!callate" {
			b.mu.Lock()
			b.state.ChatMode = false
			b.state.JokeMode = false
			b.save()
			b.mu.Unlock()
			b.send(m.Info.Chat, "🤐 Modo charla DESACTIVADO.")
			return
		}
		if admin && command == "!llegotupapariber" {
			b.mu.Lock()
			b.state.ChatMode = true
			b.state.JokeMode = true
			b.save()
			b.mu.Unlock()
			b.send(m.Info.Chat, "😂 Modo broma activado. Para apagarlo: !callate")
			return
		}
		if strings.HasPrefix(command, "!") {
			return
		}
		if jokeMode {
			b.send(m.Info.Chat, "😂 ¡Llegó tu papá, preparen la cancha que hoy se juega!")
			return
		}
		if chatMode {
			go b.replyNexusAI(m.Info.Chat, "gemini", text)
		}
		return
	}
	// Si el administrador está en el paso de adjuntar el contenido de !mensaje,
	// la imagen es el mensaje a difundir y no un comprobante de pago.
	if message != nil && message.GetImageMessage() != nil {
		if b.handleAdminImageFlow(m.Info.Chat, number, message.GetImageMessage(), string(m.Info.ID)) {
			return
		}
	}
	// Una foto SOLO se considera comprobante si este jugador confirmó asistencia,
	// eligió TRANSFERENCIA y todavía tiene pendiente presentar/reponer el recibo.
	// Las fotos normales no generan avisos ni bloquean otros manejadores.
	if message != nil && message.GetImageMessage() != nil && !isStickerCommand(body) {
		receiptHandled := false
		receiptName := ""
		b.mu.Lock()
		p, registered := b.findAny(number)
		if registered && b.state.Match.Name != "" {
			a, exists := b.state.Match.Answers[p.Number]
			if exists && a.Status == "SI" && a.PaymentMethod == "TRANSFERENCIA" && !a.Paid && (!a.ReceiptReceived || a.PaymentRejected) {
				a.ReceiptReceived = true
				a.PaymentRejected = false
				b.state.Match.Answers[p.Number] = a
				b.save()
				receiptHandled = true
				receiptName = p.Name
			}
		}
		b.mu.Unlock()
		if receiptHandled {
			log.Printf("COMPROBANTE RECIBIDO | %s", receiptName)
			b.notifyAdmins("📸 " + receiptName + " envió una foto como comprobante. Revisá la imagen; el bot no verifica el pago automáticamente.")
			b.send(m.Info.Chat, "📸 Recibí tu imagen. El administrador revisará el comprobante.")
			return
		}
	}
	if body == "" {
		return
	}
	b.handle(m.Info.Chat, number, body, string(m.Info.ID))
}

func loadState() State {
	s := State{Players: append([]Player{}, initialPlayers...), Match: Match{Answers: map[string]Answer{}}}
	raw, e := os.ReadFile(stateFile)
	if e == nil {
		var old State
		if json.Unmarshal(raw, &old) == nil {
			if len(old.Players) > 0 {
				s.Players = old.Players
			}
			s.ListOnly = old.ListOnly
			s.Blocked = old.Blocked
			s.ChatMode = old.ChatMode
			s.JokeMode = old.JokeMode
			s.AutoAI = old.AutoAI
			s.Match = old.Match
			if s.Match.Answers == nil {
				s.Match.Answers = map[string]Answer{}
			}
			// Actualiza los nombres administrativos también en estados guardados antiguos.
			for i := range s.Players {
				for _, a := range admins {
					if clean(s.Players[i].Number) == clean(a.Number) {
						s.Players[i].Name = a.Name
					}
				}
			}
			for key, answer := range s.Match.Answers {
				for _, a := range admins {
					if clean(answer.Number) == clean(a.Number) || clean(key) == clean(a.Number) {
						answer.Name = a.Name
						s.Match.Answers[key] = answer
					}
				}
			}
			if s.Match.Active && s.Match.KickoffAt.IsZero() {
				if kickoff, err := parseMatchDate(s.Match.Day, s.Match.Hour, time.Now()); err == nil {
					s.Match.KickoffAt = kickoff
					closeAt := kickoff.Add(-20 * time.Minute)
					if s.Match.ExpiresAt.IsZero() || closeAt.Before(s.Match.ExpiresAt) {
						s.Match.ExpiresAt = closeAt
					}
				}
			}
		}
	}
	return s
}
func main() {
	_ = os.MkdirAll(".", 0700)
	b := &Bot{state: loadState(), flow: map[string]string{}, temp: map[string]map[string]string{}, seen: map[string]time.Time{}, history: map[string][]StoredMessage{}, aiContext: map[string][]chatMessage{}}
	b.loadHistory()
	loadNexusRPG()
	// Revisa cierres automáticos incluso después de reiniciar Termux.
	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			b.mu.Lock()
			if b.state.Match.Active {
				now := time.Now()
				if !b.state.Match.KickoffAt.IsZero() && !now.Before(b.state.Match.KickoffAt.Add(-20*time.Minute)) {
					b.closeMatchLocked("faltan 20 minutos para el partido")
				} else if !b.state.Match.ExpiresAt.IsZero() && !now.Before(b.state.Match.ExpiresAt) {
					b.closeMatchLocked("venció el plazo máximo de 5 horas")
				}
			}
			b.mu.Unlock()
		}
	}()
	ctx := context.Background()
	dbLog := waLog.Stdout("DB", "ERROR", true)
	// One SQLite connection serializes writes and avoids SQLITE_BUSY from concurrent writers.
	dsn := "file:" + filepath.Join(".", dbFile) + "?_pragma=foreign_keys(1)&_pragma=busy_timeout(10000)&_pragma=journal_mode(WAL)"
	sqlDB, e := sql.Open("sqlite", dsn)
	if e != nil {
		log.Fatal("No se pudo abrir SQLite: ", e)
	}
	sqlDB.SetMaxOpenConns(1)
	sqlDB.SetMaxIdleConns(1)
	container := sqlstore.NewWithDB(sqlDB, "sqlite", dbLog)
	if e = container.Upgrade(ctx); e != nil {
		log.Fatal("No se pudo actualizar la base de sesión: ", e)
	}
	device, e := container.GetFirstDevice(ctx)
	if e != nil {
		log.Fatal(e)
	}
	client := whatsmeow.NewClient(device, waLog.Stdout("WA", "ERROR", true))
	b.client = client
	client.AddEventHandler(b.onEvent)
	if device.ID == nil {
		qr, err := client.GetQRChannel(ctx)
		if err != nil {
			log.Fatal(err)
		}
		if err = client.Connect(); err != nil {
			log.Fatal(err)
		}
		for evt := range qr {
			if evt.Event == "code" {
				fmt.Println("Escaneá este QR desde WhatsApp > Dispositivos vinculados:")
				qrterminal.GenerateHalfBlock(evt.Code, qrterminal.L, os.Stdout)
			} else if evt.Event == "success" {
				fmt.Println("Vinculación completada.")
			}
		}
	} else if e = client.Connect(); e != nil {
		log.Fatal(e)
	}
	self := "desconocido"
	if client.Store.ID != nil {
		self = clean(client.Store.ID.User)
	}
	b.ownNumber = self
	log.Printf("CUENTA_CONECTADA | numero=%s | jid=%s", self, client.Store.ID)
	fmt.Println("NEXUS TITAN conectado. Número propio:", self, "| Administradores:", admins[0].Number, "y", admins[1].Number)
	fmt.Printf("Plantel: %d/%d | Cupo por partido: %d\n", len(b.state.Players), maxRoster, maxPlayers)
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, os.Interrupt, syscall.SIGTERM)
	<-ch
	fmt.Println("Cerrando bot...")
	client.Disconnect()
	b.mu.Lock()
	b.save()
	b.mu.Unlock()
}
