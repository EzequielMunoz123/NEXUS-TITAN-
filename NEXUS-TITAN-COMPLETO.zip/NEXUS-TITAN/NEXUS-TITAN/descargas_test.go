package main

import "testing"

func TestDownloadPlatformAliases(t *testing.T) {
	cases := map[string]string{
		"!tiktok": "TikTok", "?tiktok": "TikTok", "!tt": "TikTok", "?tt": "TikTok",
		"!youtube": "YouTube", "?youtube": "YouTube", "!yt": "YouTube", "?yt": "YouTube",
		"!instagram": "Instagram", "?instagram": "Instagram", "!ig": "Instagram", "?ig": "Instagram",
	}
	for command, want := range cases {
		if got := downloadPlatform(command); got != want {
			t.Errorf("downloadPlatform(%q) = %q; want %q", command, got, want)
		}
	}
	if got := downloadPlatform("!facebook"); got != "" {
		t.Errorf("downloadPlatform(unsupported) = %q; want empty", got)
	}
}

func TestRequestedDownloadFormat(t *testing.T) {
	cases := []struct {
		fields []string
		want   string
	}{
		{[]string{"mp3"}, "mp3"},
		{[]string{"MP3"}, "mp3"},
		{[]string{"audio"}, "mp3"},
		{[]string{"mp4"}, "mp4"},
		{[]string{"video"}, "mp4"},
		{[]string{"calidad", "mp3"}, "mp3"},
		{[]string{}, ""},
	}
	for _, tc := range cases {
		if got := requestedDownloadFormat(tc.fields); got != tc.want {
			t.Errorf("requestedDownloadFormat(%v) = %q; want %q", tc.fields, got, tc.want)
		}
	}
}
