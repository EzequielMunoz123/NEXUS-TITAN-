package main

import "testing"

func TestAnswerNaturalMatchReplies(t *testing.T) {
	cases := map[string]string{
		"SI":               "SI",
		"Te pongo un Si":   "SI",
		"Si pue compa":     "SI",
		"Dale, voy de una": "SI",
		"Cuenta conmigo":   "SI",
		"No puedo ir":      "NO",
		"Esta vez no":      "NO",
		"No, gracias":      "NO",
		"No sé si puedo":   "",
		"Hola cómo estás":  "",
	}
	for input, want := range cases {
		if got := answer(input); got != want {
			t.Errorf("answer(%q) = %q; want %q", input, got, want)
		}
	}
}
