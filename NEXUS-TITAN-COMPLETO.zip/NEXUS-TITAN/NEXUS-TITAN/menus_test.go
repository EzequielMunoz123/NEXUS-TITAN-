package main

import (
	"strings"
	"testing"
)

func TestMenuResponsePlainTextAliases(t *testing.T) {
	cases := []string{"!menu", "!MENU", "/menu", ".menu", "menu", "!ayuda", "!help", "!menu!", "!menu.", "!menu@5493734419761", "!menu\u200b", "?", "?menu"}
	for _, input := range cases {
		got, ok := menuResponse(input, true)
		if !ok {
			t.Errorf("menuResponse(%q) no reconoció el comando", input)
			continue
		}
		if !strings.Contains(got, "NEXUS TITAN") {
			t.Errorf("menuResponse(%q) no devolvió el menú", input)
		}
	}
}

func TestMenuResponseDoesNotReturnInteractivePayload(t *testing.T) {
	got, ok := menuResponse("!menu", false)
	if !ok {
		t.Fatal("!menu no reconocido")
	}
	if strings.Contains(strings.ToLower(got), "nativeflow") || strings.Contains(strings.ToLower(got), "button") {
		t.Fatalf("el menú contiene referencias a botones: %q", got)
	}
}

func TestAllMenuAlias(t *testing.T) {
	got, ok := menuResponse("!allmenu", true)
	if !ok || !strings.Contains(got, "SOLO ADMINISTRADORES") || !strings.Contains(got, "SISTEMA") {
		t.Fatal("!allmenu no devolvió el menú completo")
	}
}

func TestPublicMenuHidesAdminCommands(t *testing.T) {
	got, ok := menuResponse("!menu", false)
	if !ok {
		t.Fatal("!menu no reconocido")
	}
	for _, command := range []string{"!tiktok", "?tiktok", "!youtube", "?youtube", "!instagram", "?instagram", "!sticker", "?sticker", "!audio", "mp3", "mp4"} {
		if !strings.Contains(got, command) {
			t.Errorf("falta %q en el menú público", command)
		}
	}
	if strings.Contains(got, "• !partido —") || strings.Contains(got, "!finalizar") || strings.Contains(got, "!confirmarpago") {
		t.Fatal("se filtraron comandos administrativos")
	}
}
